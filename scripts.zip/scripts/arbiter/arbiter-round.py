#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
arbiter-round.py —— 仲裁节点的**一个观测周期**（§5 M1.1）

由 run-adapters.sh 调用（那个脚本只负责锁与入口），每 30 秒一轮。

一轮做四件事，跑完把结果原子地写进 $ARBITER_STATE_DIR/adapters.json：

  ① 自检闸 —— 证明"我自己的网络此刻是通的"
  ② VIP 归属 —— 谁在应答这个地址、MAC 是谁
  ③ 逐个适配器 —— 对**每个节点**都跑一遍全部适配器（$1 = 该节点的对端 IP）
  ④ 复制实况 —— 主库侧 pg_stat_replication 里有没有备库在 streaming

★★ 本程序只读。它不启动、不停止、不重启任何东西，也不下发任何指令。
   适配器同理，见 §5 M1.1 的契约。

★ 为什么这一轮的核心逻辑是 Python 而不是 bash：
  适配器的**执行与归类**要处理超时、非 0/1/2 的退出码、stdout 解析、
  不可用轮次的累计 —— 这些在 bash 里全靠在字符串上做判断，
  而它们的每一种错法都会**静默地**把"我们自己瞎了"变成"对端不在服务"。
"""

import argparse
import json
import os
import re
import socket
import subprocess
import sys
import time
from datetime import datetime

sys.path.insert(0, "/opt/zbx-arbiter")

DEFAULT_STATE_DIR = "/var/lib/zbx-arbiter"
DEFAULT_ADAPTER_DIR = "/etc/zbx-arbiter/adapters"


def log(msg):
    print("[%s] %s" % (datetime.now().strftime("%F %T"), msg))
    sys.stdout.flush()


def now_iso():
    return datetime.now().astimezone().isoformat(timespec="seconds")


# ============================================================
# 配置（★ 解析规则必须与节点侧一致：只认整行注释）
# ============================================================

def parse_conf(path):
    d = {}
    if not os.path.exists(path):
        return d
    with open(path, encoding="utf-8-sig") as f:
        for line in f:
            s = line.strip()
            if not s or s.startswith("#") or "=" not in s:
                continue
            k, v = s.split("=", 1)
            k, v = k.strip(), v.strip()
            if len(v) >= 2 and v[0] == v[-1] and v[0] in ("'", '"'):
                v = v[1:-1]
            d[k] = v
    return d


def getint(d, k, default):
    try:
        return int((d.get(k) or "").strip())
    except ValueError:
        return default


# ============================================================
# ① 自检闸
#
# 它挡的是：仲裁节点自己网络没就绪时，ping 不通 → 记"对端不在服务"、
# 端口连不上 → 记"对端不在服务"、arping 无应答 → 记"VIP 空闲"，
# 于是**每条判据都"通过"，因为它看不见任何东西**。
# 那不是缺少检查，是缺少"我能不能看见"这个前置。
# ============================================================

def ping(host, timeout=2):
    try:
        r = subprocess.run(["ping", "-c", "1", "-W", str(timeout), host],
                           capture_output=True, timeout=timeout + 3)
        return r.returncode == 0
    except Exception:
        return False


def tcp_ok(host, port, timeout=3):
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def selfcheck(targets):
    """返回 {"ok":bool, "reason":str, "targets":[...]}。

    ★ 没配目标 = 自检闸形同虚设。此时必须报 ok=false ——
      宁可让全部判定变成 unknown（保守），也不要假装自检通过了。
    """
    if not targets:
        return {"ok": False, "targets": [],
                "reason": "SELFCHECK_TARGETS 未配置，无法证明本机网络可用"}
    items, all_ok = [], True
    for t in targets:
        host, port = t, None
        if ":" in t:
            h, _, p = t.partition(":")
            if p.isdigit():
                host, port = h, int(p)
        ok = tcp_ok(host, port) if port else ping(host)
        all_ok = all_ok and ok
        items.append({"target": t, "ok": ok})
    return {"ok": all_ok, "targets": items,
            "reason": ("自检目标全部可达" if all_ok
                       else "有自检目标不可达，本机观测不可采信")}


# ============================================================
# ② VIP 归属
# ============================================================

# ★ 三处发行版差异之二：`arping` 是**两个包**，装错的那个永远赢。
#   iputils-arping → /usr/bin/arping      （要的就是它：有 -D，输出 "Received N response(s)"）
#   arping         → /usr/sbin/arping     （Habets 版：没有 -D 语义，输出 "reply(s)"）
#   systemd 的 PATH 里 /usr/sbin 在 /usr/bin 之前，所以"哪个先被找到"由包决定，
#   不由写法决定 —— 直接写 `arping` 就是在赌运气。
ARPING_CANDIDATES = ["/usr/bin/arping", "/bin/arping",
                     "/usr/sbin/arping", "/sbin/arping"]


def resolve_arping(conf):
    """定出要用哪个 arping，并**功能验证**它是 iputils 版。

    返回 (路径, 说明)；路径为 "" 表示不可用（此时一切 VIP 判定都必须按未知处理）。

    ★ 不靠 `which`：那条路正是被 PATH 顺序决定的那条。
    ★ 不只看版本串：`-V` 在各版本里时有时无，所以再补一次真实探测，
      看输出里有没有 iputils 特有的 "response(s)" 措辞。
    """
    explicit = (conf.get("ARPING_BIN") or "").strip()
    cands = [explicit] if explicit else []
    cands += [p for p in ARPING_CANDIDATES if p not in cands]

    tried = []
    for p in cands:
        if not p or not os.path.isfile(p) or not os.access(p, os.X_OK):
            continue
        try:
            v = subprocess.run([p, "-V"], capture_output=True, text=True,
                               timeout=5)
            vtxt = ((v.stdout or "") + (v.stderr or "")).lower()
        except Exception:
            vtxt = ""
        if "iputils" in vtxt:
            return p, "%s（版本串自报 iputils）" % p
        tried.append("%s：-V 输出里没有 iputils 字样" % p)

    # 版本串判不出来 —— 退一步做一次真实探测，看措辞
    for p in cands:
        if not p or not os.path.isfile(p) or not os.access(p, os.X_OK):
            continue
        try:
            r = subprocess.run([p, "-c", "1", "-w", "2", "127.0.0.1"],
                               capture_output=True, text=True, timeout=8)
            blob = ((r.stdout or "") + (r.stderr or ""))
        except Exception:
            continue
        if re.search(r"Received\s+\d+\s+response", blob):
            return p, "%s（探测输出是 iputils 措辞）" % p
        tried.append("%s：探测输出里没有 'Received N response'" % p)

    return "", ("找不到 iputils-arping。" +
                ("；".join(tried) if tried else
                 "候选路径 %s 全都不存在（apt install iputils-arping）"
                 % "、".join(ARPING_CANDIDATES)))


def arping(binary, nic, target, dad=True, count=3, timeout=15):
    """跑一次 arping。返回 (应答数, mac 集合, 原始输出)。

    应答数 None = **无法判断**（找不到命令/超时/输出不认识）。
    ★ 解析不了就是未知 —— 绝不能退回"按退出码判断"。
      一个认不出来的输出，不该变成一句"VIP 空闲"。
    ★★ 也不看 DAD 的退出码：iputils 的 -D 在若干版本里退出码与文档不符，
      而这里的每一种误读都会把"我们瞎了"变成"VIP 空闲"。
    """
    if not binary:
        return None, set(), "没有可用的 iputils-arping"
    args = [binary] + (["-D"] if dad else []) + \
           ["-I", nic, "-c", str(count), target]
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
    except FileNotFoundError:
        return None, set(), "找不到 arping 命令（apt install iputils-arping）"
    except subprocess.TimeoutExpired:
        return None, set(), "arping 超时"
    blob = (r.stdout or "") + (r.stderr or "")
    macs = set()
    for tok in blob.replace("[", " ").replace("]", " ").split():
        t = tok.strip().lower()
        if len(t) == 17 and t.count(":") == 5:
            macs.add(t)
    m = re.search(r"Received\s+(\d+)\s+response", blob)
    if m:
        return int(m.group(1)), macs, blob.strip()[:300]
    return None, macs, blob.strip()[:300]


def probe_nic(conf):
    nic = (conf.get("NIC") or "").strip()
    if nic:
        return nic
    vip = (conf.get("VIP") or "").strip()
    if not vip:
        return ""
    try:
        r = subprocess.run(["ip", "route", "get", vip],
                           capture_output=True, text=True, timeout=5)
        m = re.search(r"\bdev\s+(\S+)", r.stdout or "")
        return m.group(1) if m else ""
    except Exception:
        return ""


def learn_macs(state_dir, nodes):
    """学习/更新两台节点的 MAC，并记录"它此刻在不在网上"。

    返回 (macs, alive)
    """
    path = os.path.join(state_dir, "macs.json")
    try:
        with open(path, encoding="utf-8-sig") as f:
            macs = json.load(f)
    except (OSError, ValueError):
        macs = {}
    alive = {}
    for n in nodes:
        if not n:
            continue
        alive[n] = ping(n, timeout=1)
        if not alive[n]:
            continue
        try:
            r = subprocess.run(["ip", "neigh", "show", n],
                               capture_output=True, text=True, timeout=5)
        except Exception:
            continue
        m = re.search(r"lladdr\s+([0-9a-fA-F:]{17})", r.stdout or "")
        if m:
            macs[n] = m.group(1).lower()
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(macs, f, indent=1)
    except OSError:
        pass
    return macs, alive


def probe_vip(conf, nic, macs, nodes, arping_bin):
    """返回 {"holder_mac","answerers","vip","nic","by"}。

    ★ holder_mac 为 None 表示"确实没人应答"。
      取不到 MAC 但确实有应答时，holder_mac 为 "unknown-mac" ——
      这个区分很重要：前者是"VIP 空闲"，后者是"有人但我认不出它是谁"。
    """
    vip = (conf.get("VIP") or "").strip()
    out = {"vip": vip, "nic": nic, "holder_mac": None, "answerers": [], "by": "none"}
    if not nic or not vip:
        out["by"] = "unknown"
        return out
    if not arping_bin:
        out["holder_mac"] = "unknown-mac"
        out["by"] = "unknown"
        out["raw"] = "没有可用的 iputils-arping"
        return out

    n, macs_seen, raw = arping(arping_bin, nic, vip, dad=True)
    if n is None:
        # 连"有没有人应答"都不知道 —— 记成 unknown，不能记成空闲
        out["holder_mac"] = "unknown-mac"
        out["by"] = "unknown"
        out["raw"] = raw
        return out
    if n == 0:
        return out

    _, macs2, raw2 = arping(arping_bin, nic, vip, dad=False)
    answerers = sorted(macs2 or macs_seen)
    out["answerers"] = answerers
    if answerers:
        out["holder_mac"] = answerers[0]
        for node in nodes:
            if node and macs.get(node) == answerers[0]:
                out["by"] = node
                break
        else:
            out["by"] = "unknown"
    else:
        out["holder_mac"] = "unknown-mac"
        out["by"] = "unknown"
    out["raw"] = raw2
    return out


# ============================================================
# ③ 逐个适配器
#
# 契约（§5 M1.1）：$1 = 待判定的**对端** IP；退出 0/1/2/3；
#                 stdout 第一行进 reason，其余进行原始观测值。
#
#   0 = 证据成立（对端确实不在服务）    1 = 证据不成立（对端在服务）
#   2 = 不可用（我们自己瞎了）          3 = 无结论（看了，但看不出）
# ============================================================

def list_adapters(adapter_dir):
    try:
        names = [n for n in os.listdir(adapter_dir)
                 if os.path.isfile(os.path.join(adapter_dir, n))
                 and os.access(os.path.join(adapter_dir, n), os.X_OK)]
    except OSError:
        return []
    return sorted(names)


def adapter_env(conf, node, peer, macs):
    """给适配器的环境变量。

    契约里说"环境：ARBITER_* 全套配置" —— 这里把配置原样交出去
    （VIP / NIC / NODE_A_IP / NODE_B_IP / ARBITER_* 都在），
    另外补三个只在运行时才知道的：

        ARBITER_SELF_IP    正在被**判定**的那台节点
        ARBITER_SELF_MAC   它的 MAC
        ARBITER_PEER_IP    适配器 $1 那台（被观测的对端）
        ARBITER_PEER_MAC   对端的 MAC（★ 从本机 ARP 邻居表学到，可能为空）

    ★ 前三个是判据①（VIP 归属）必需的：适配器只有知道"请求方自己是谁"，
      才能区分"应答者是请求方自己"（通过）与"应答者是对端或第三方"（拒绝）。

    ★ ARBITER_PEER_MAC 是 SNMP 与 ESXi 观测的入口：
      这两路观测问的都是"**对端这个 MAC** 还在不在？"，没有它就无从查起。
      学到过就是学到的那个值，**不随本轮 ping 不通而清空** ——
      恰恰在对端已经下线的时候，我们最需要这个 MAC。
    """
    env = os.environ.copy()
    for k, v in conf.items():
        if isinstance(v, str):
            env[k] = v
    env["ARBITER_SELF_IP"] = node
    env["ARBITER_SELF_MAC"] = macs.get(node) or ""
    env["ARBITER_PEER_IP"] = peer
    env["ARBITER_PEER_MAC"] = macs.get(peer) or ""
    return env


def run_one(adapter_dir, name, peer, timeout, env):
    """跑一个适配器。返回 (rc, reason, raw)。

    ★★ rc 的四态语义必须严格保住：
       0  证据成立（对端确实不在服务）
       1  证据不成立（对端在服务）—— 设计意图，该拦住
       2  不可用（我们自己瞎了）—— 需要人来修的故障
       3  无结论（看了，但看不出）—— 判据型适配器的退路，降级成否决型
       **任何其它退出码、超时、崩溃，统统归到 2。**

       把 2 悄悄算成 0，就是把"监控失效"伪装成"对端不在服务"；
       把 3 算成 1，就是拿"对端开着机"当"对端在服务" —— 那会掐死主库的冷启动。
       两者都是本方案里最危险的那类错误，所以这里逐个显式处理。
    """
    path = os.path.join(adapter_dir, name)
    try:
        r = subprocess.run([path, peer], capture_output=True, text=True,
                           timeout=timeout, env=env)
        rc, out, err = r.returncode, r.stdout or "", r.stderr or ""
    except subprocess.TimeoutExpired:
        return 2, "适配器超时（> %ds）" % timeout, ""
    except OSError as e:
        return 2, "适配器无法执行: %s" % e, ""

    if rc not in (0, 1, 2, 3):
        raw = (out + err).strip()
        return 2, "适配器返回了非法退出码 %s（只认 0/1/2/3）" % rc, raw[:2000]

    lines = out.splitlines()
    reason = (lines[0].strip() if lines and lines[0].strip()
              else "（适配器没有输出理由）")
    raw = "\n".join(lines[1:21])[:2000] or (err.strip()[:2000])
    return rc, reason, raw


STATE_OF_RC = {0: "ok", 1: "denied", 2: "unavailable", 3: "no_conclusion"}


def run_adapters(conf, adapter_dir, nodes, macs):
    timeout = getint(conf, "ADAPTER_TIMEOUT", 10)
    names = list_adapters(adapter_dir)
    if not names:
        log("★ 适配器目录 %s 里没有任何可执行文件 —— 判定将全部为 unknown"
            % adapter_dir)

    state_dir = (conf.get("ARBITER_STATE_DIR") or DEFAULT_STATE_DIR).strip()
    health_path = os.path.join(state_dir, "adapter_health.json")
    try:
        with open(health_path, encoding="utf-8-sig") as f:
            health = json.load(f)
    except (OSError, ValueError):
        health = {}

    rows = []
    epoch = int(time.time())
    for name in names:
        for node in nodes:
            if not node:
                continue
            peer = [x for x in nodes if x and x != node]
            peer = peer[0] if peer else ""
            if not peer:
                continue
            t0 = int(time.time())
            env = adapter_env(conf, node, peer, macs)
            rc, reason, raw = run_one(adapter_dir, name, peer, timeout, env)
            key = "%s|%s" % (node, name)
            # ★ 只有"不可用"才累计退化轮次。返回 3 的适配器**在正常工作**，
            #   只是这一路观测回答不了这个问题，把它算成退化会造成常年误报。
            health[key] = (health.get(key, 0) + 1) if rc == 2 else 0
            rows.append({
                "node": node, "name": name, "rc": rc,
                "state": STATE_OF_RC[rc],
                "reason": reason, "raw": raw,
                "ts": datetime.fromtimestamp(t0).astimezone().isoformat(timespec="seconds"),
                "epoch": t0, "age_sec": epoch - t0,
                "unavailable_rounds": health[key],
            })
            if rc == 2:
                log("  适配器 %s 对 %s 不可用：%s" % (name, node, reason))
            elif rc == 3:
                log("  适配器 %s 对 %s 无结论（降级为否决型）：%s"
                    % (name, node, reason))

    try:
        with open(health_path, "w", encoding="utf-8") as f:
            json.dump(health, f, indent=1)
    except OSError:
        pass
    return names, rows


# ============================================================
# ④ 复制实况
#
# ★★ 判据必须是"**真实复制**"，不是"那台还活着"。
#    一台备库可以活着、PG 在跑、pg_is_in_recovery()=t，但根本没在复制 ——
#    它会安静地待着，看起来完全正常（U4）。这正是主功能 F2 最可能的落点。
# ============================================================

def pg_query(conf, host, sql):
    """用 probe 账号连过去执行一条查询。返回 (值, 错误)。"""
    psql = (conf.get("PSQL") or "/usr/bin/psql").strip()
    if not os.path.exists(psql):
        for cand in ("/usr/bin/psql", "/usr/lib/postgresql/17/bin/psql",
                     "/usr/lib/postgresql/16/bin/psql"):
            if os.path.exists(cand):
                psql = cand
                break
    env = os.environ.copy()
    env["PGPASSWORD"] = (conf.get("PROBE_PWD") or "").strip()
    try:
        r = subprocess.run(
            [psql, "-X", "-q", "-t", "-A", "-h", host, "-p", "5432",
             "-U", (conf.get("PROBE_USER") or "probe").strip(),
             "-d", "postgres", "-c", sql],
            capture_output=True, text=True, timeout=10, env=env)
    except Exception as e:
        return None, str(e)
    if r.returncode != 0:
        return None, (r.stderr or r.stdout or "").strip()[:200]
    return (r.stdout or "").strip(), ""


def check_replication(conf, nodes):
    """主库侧看：备库到底在不在 streaming。"""
    out = {"streaming": False, "slot": "", "detail": "", "primary": ""}
    primary, errs = "", []
    for n in nodes:
        if not n:
            continue
        v, err = pg_query(conf, n, "SELECT pg_is_in_recovery();")
        if v == "f":
            primary = n
        elif v is None:
            errs.append("%s: %s" % (n, err))
    if not primary:
        out["detail"] = ("没有任何节点自报主库（或 probe 账号连不上：%s），"
                         "无法确认备库是否在复制" % ("；".join(errs) or "无错误信息"))
        return out
    out["primary"] = primary

    others = [n for n in nodes if n and n != primary]
    if not others:
        out["detail"] = "配置里只有一台节点，无从谈起备库"
        return out
    standby = others[0]
    slot = "slot_%s" % standby.split(".")[-1]
    out["slot"] = slot

    # ★★ pg_stat_replication 没有 slot_name 这一列，它在 pg_replication_slots。
    #    物理复制下 walsender 与槽的关联只能靠 pg_replication_slots.active_pid。
    #    ★ 用 probe 账号读 state 需要 GRANT pg_read_all_stats，否则 PG **行照给、
    #      state 给 NULL** —— 空串会落到下面的 elif state == ""，与"槽不活动"同话术。
    state, err = pg_query(conf, primary,
                          "SELECT COALESCE(s.state,'') FROM pg_replication_slots r "
                          "JOIN pg_stat_replication s ON s.pid = r.active_pid "
                          "WHERE r.slot_name='%s';" % slot)
    if state is None:
        out["detail"] = "查询主库 %s 的 pg_stat_replication 失败：%s" % (primary, err)
    elif state == "streaming":
        out["streaming"] = True
        out["detail"] = "主库 %s 上槽 %s 处于 streaming" % (primary, slot)
    elif state == "":
        out["detail"] = ("★ 主库 %s 上槽 %s 没有任何 wal sender —— 备库没有在复制。\n"
                         "  注意：备库可能活着、PG 在跑、pg_is_in_recovery()=t，"
                         "但根本没在复制（U4）。" % (primary, slot))
    else:
        out["detail"] = "主库 %s 上槽 %s 状态为 %s（不是 streaming）" % (primary, slot, state)
    return out


# ============================================================
# 主流程
# ============================================================

def write_json_atomic(state_dir, name, obj):
    os.makedirs(state_dir, exist_ok=True)
    tmp = os.path.join(state_dir, name + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)
    os.replace(tmp, os.path.join(state_dir, name))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--conf", default="/etc/zbx-arbiter/arbiter.conf")
    args = ap.parse_args()

    conf = parse_conf(args.conf)
    state_dir = (conf.get("ARBITER_STATE_DIR") or DEFAULT_STATE_DIR).strip()
    adapter_dir = (conf.get("ARBITER_ADAPTER_DIR") or DEFAULT_ADAPTER_DIR).strip()
    nodes = [(conf.get("NODE_A_IP") or "").strip(),
             (conf.get("NODE_B_IP") or "").strip()]

    os.makedirs(state_dir, exist_ok=True)

    # ---- 单实例保护：观测周期必须串行 ----
    lock_path = os.path.join(state_dir, ".obs.lock")
    lock_fd = open(lock_path, "w")
    try:
        import fcntl
        fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except (OSError, ImportError):
        log("上一轮观测还在跑，本轮跳过")
        return 0

    t_start = time.time()
    log("开始观测周期（适配器目录 %s）" % adapter_dir)

    # ① 自检闸
    sc = selfcheck([t for t in re.split(
        r"[,\s]+", (conf.get("SELFCHECK_TARGETS") or "").strip()) if t])
    log("  自检闸：%s（%s）" % ("通过" if sc["ok"] else "★ 未通过", sc["reason"]))

    # ② VIP 与节点
    macs, alive = learn_macs(state_dir, nodes)
    nic = probe_nic(conf)
    # ★★ 把推导出来的网卡名**写回 conf** —— 适配器的配置是从环境变量来的
    #    （adapter_env = 全部 conf 键 + ARBITER_*），而 NIC **在适配器里没有默认值**：
    #    10-network.sh 做的第一件事就是 `[ -z "$VIP" ] || [ -z "$NIC" ] → exit 2`。
    #
    #    不写回的话，10-network.sh 会永远返回「不可用（rc=2）」，而它是判据①
    #    （VIP 归属）唯一的底 —— 于是每个节点的判定都停在 unknown，
    #    **谁也不能冷启动，F1 直接失败**。而它不会报任何错，只会一直"不可用"。
    #
    #    （conf 里显式填了 NIC 时，probe_nic 返回的就是它，这一行等于不变。）
    if nic:
        conf["NIC"] = nic
    else:
        log("  ★ 没能确定网卡：NIC 为空且 `ip route get <VIP>` 也推不出来 —— "
            "适配器会因此整片返回「不可用」，判定将停在 unknown。")
    arping_bin, arping_note = resolve_arping(conf)
    log("  arping：%s" % (arping_note or "（不可用）"))
    vip = probe_vip(conf, nic, macs, nodes, arping_bin)
    log("  VIP %s：holder_mac=%s by=%s，节点存活 %s"
        % (vip.get("vip"), vip.get("holder_mac"), vip.get("by"), alive))
    for n in nodes:
        if n and n not in alive:
            alive[n] = None

    # ③ 适配器
    names, rows = run_adapters(conf, adapter_dir, nodes, macs)
    log("  适配器：%s" % (", ".join(names) if names else "（无）"))

    # ④ 复制实况
    repl = check_replication(conf, nodes)
    log("  复制：streaming=%s（%s）" % (repl["streaming"], repl["detail"]))

    # ---- 组装 ----
    by_node = {}
    for r in rows:
        by_node.setdefault(r["node"], {"adapters": [], "alive": alive.get(r["node"])})
        by_node[r["node"]]["adapters"].append(r)
    for n in nodes:
        if n and n not in by_node:
            by_node[n] = {"adapters": [], "alive": alive.get(n)}

    out = {
        "run_at": now_iso(),
        "run_epoch": int(time.time()),
        "duration_sec": round(time.time() - t_start, 1),
        "selfcheck": sc,
        "vip": vip,
        "replication": repl,
        "configured": names,
        "nodes": by_node,
    }
    write_json_atomic(state_dir, "adapters.json", out)
    log("观测周期结束（%.1fs），adapters.json 已更新" % out["duration_sec"])
    return 0


if __name__ == "__main__":
    sys.exit(main())
