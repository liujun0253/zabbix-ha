#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
arbiter.py —— 仲裁节点（★ 部署在第三台机器上，Ubuntu 22.04）

对应需求：§5 M1。职责：
  · 从第三视角观测两台节点与 VIP，对每个节点回答**同一个问题**：
    「它现在能不能当主库？」
  · 对外提供**只读**接口：/verdict（许可）、/state 与 /metrics（监控）、/files（分发）
  · 检测双主并告警

★★ 永久只读：本文件里没有任何一行会去启动/停止/重启/关机/开机。
   它不执行任何动作，只回答"能不能"。它挂了，两台节点都会因拿不到许可而
   拒绝成为主库（fail-closed）—— 这是刻意的失效方向。

运行模型（§5 M1.1）：
   zbx-arbiter.timer 每 30 秒触发 run-adapters.sh，跑完一轮把结果写进
   $ARBITER_STATE_DIR/adapters.json。
   **/verdict 只读这个状态文件并计算新鲜度，不在请求里实时跑适配器** ——
   REST 服务以非 root 跑，而适配器需要 SNMP/IPMI 特权，两者必须解耦；
   更重要的是节点不该为一个判定的响应时间负责。

只用标准库。
"""

import hashlib
import hmac
import json
import os
import re
import sys
import threading
import time
import urllib.parse
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ARBITER_DIR = "/opt/zbx-arbiter"
CONF_FILE = "/etc/zbx-arbiter/arbiter.conf"
DEFAULT_STATE_DIR = "/var/lib/zbx-arbiter"
DEFAULT_ADAPTER_DIR = "/etc/zbx-arbiter/adapters"

# ★ 2：维护窗口改成**全局**后，/state 的 maintenance 对象少了 node、多了 scope。
#   节点侧**永远不许读**这个版本号（02 §9.2），它只是给排障的人与将来留的痕迹。
SCHEMA_VERSION = 2

# 综合状态的严重度次序。取"任选其一"时按这个顺序从上往下第一个命中的。
STATE_ORDER = ["BLIND", "SPLIT_BRAIN", "NO_PRIMARY", "MAINTENANCE",
               "NO_STANDBY", "DEGRADED_EVIDENCE", "OK"]
SEVERITY = {"SPLIT_BRAIN": "最高", "NO_PRIMARY": "最高", "ARBITER_DOWN": "最高",
            "BLIND": "高", "NO_STANDBY": "高", "DEGRADED_EVIDENCE": "中",
            "MAINTENANCE": "提示", "OK": "正常"}


# ============================================================
# 配置
# ============================================================

def parse_conf(path):
    """★ 只把【整行以 # 开头】当注释 —— 值里可能含 #（密码），
    绝不能做行内注释剥离，否则密码会被静默截断（§8.3）。

    ★★ 用 utf-8-sig 读：有人用 Windows 的记事本（"UTF-8 带 BOM"）或
      从 Windows 共享盘拷过配置文件时，文件头会带一个 BOM。
      用普通 utf-8 读，BOM 会粘在**第一个键名**上，于是那个键**静默消失** ——
      而第一个键往往正是 NODE_A_IP。表现是"仲裁只认一台节点"，
      不报任何错。这与 §8.3 里那些"密码被悄悄截断"是同一类陷阱。
    """
    d = {}
    if not os.path.exists(path):
        return d
    with open(path, encoding="utf-8-sig") as f:
        for line in f:
            s = line.strip()
            if not s or s.startswith("#") or "=" not in s:
                continue
            k, v = s.split("=", 1)
            k, v = k.strip(), v.strip()
            if len(v) >= 2 and v[0] == v[-1] and v[0] in ("'", '"'):
                v = v[1:-1]
            d[k] = v
    return d


class Conf(object):
    def __init__(self, path=CONF_FILE):
        self.path = path
        self.d = parse_conf(path)
        self.mtime = 0
        self.reload()

    def reload(self):
        self.d = parse_conf(self.path)
        try:
            self.mtime = os.path.getmtime(self.path)
        except OSError:
            self.mtime = 0

    def maybe_reload(self):
        """每轮状态计算前看一眼 mtime，变了就重载。

        ★★ 但**不要**据此以为"改配置不用重启服务"：
          这里唯一的调用点是 build_state()，而 build_state() 只能从
          /state、/metrics、/health 走到 —— 这三个端点全都排在
          _allowed() 这道白名单检查**后面**。
          于是最需要热加载的那个键（ARBITER_ALLOW_FROM）恰好改不动：
          新加的 IP 发来的那个请求会被**旧**名单拒掉，压根走不到这里，
          名单就永远停在内存里那份旧的。

        ★ 所以运维规矩是：**改完配置就重启服务**。
          systemctl restart zbx-arbiter-http.service
          （`systemctl enable --now` 对已在运行的服务是空操作，代替不了它。）
        """
        try:
            if os.path.getmtime(self.path) != self.mtime:
                self.reload()
                log("配置已重新加载: %s" % self.path)
        except OSError:
            pass

    def get(self, k, default=None):
        return self.d.get(k, default)

    def getint(self, k, default):
        v = (self.d.get(k) or "").strip()
        try:
            return int(v)
        except ValueError:
            return default

    @property
    def nodes(self):
        """两台节点的 IP，按 NODE_A / NODE_B 次序。"""
        return [(self.d.get("NODE_A_IP") or "").strip(),
                (self.d.get("NODE_B_IP") or "").strip()]

    @property
    def state_dir(self):
        return (self.d.get("ARBITER_STATE_DIR") or DEFAULT_STATE_DIR).strip()

    @property
    def adapter_dir(self):
        return (self.d.get("ARBITER_ADAPTER_DIR") or DEFAULT_ADAPTER_DIR).strip()

    @property
    def token(self):
        return (self.d.get("ARBITER_TOKEN") or "").strip()

    @property
    def judge_level(self):
        """判据型白名单：只有列在这里的适配器能"一票通过"。

        ★ 默认清单刻意是空的 —— 安全侧的缺省必须是"最弱"，不是"最强"。
          随包提供的 20-oob-* / 30-snmp-* 在 arbiter.conf.template 里显式列出。
          写在这里当兜底的默认值，是为了让"配置文件被清空"这种事故
          退化成"所有适配器都只是否决型"（更保守），而不是退化成"都能一票通过"。
        """
        raw = (self.d.get("JUDGE_LEVEL_ADAPTERS") or "").strip()
        pats = [p.strip() for p in raw.split(",") if p.strip()]
        return pats

    def is_judge_level(self, name):
        import fnmatch
        for p in self.judge_level:
            if fnmatch.fnmatch(name, p):
                return True
        return False

    @property
    def allow_from(self):
        raw = (self.d.get("ARBITER_ALLOW_FROM") or "").strip()
        return set(x.strip() for x in re.split(r"[,\s]+", raw) if x.strip())

    @property
    def selfcheck_targets(self):
        raw = (self.d.get("SELFCHECK_TARGETS") or "").strip()
        return [x.strip() for x in re.split(r"[,\s]+", raw) if x.strip()]


def log(msg):
    line = "[%s] %s" % (datetime.now().strftime("%F %T"), msg)
    print(line)
    sys.stdout.flush()


def now_iso():
    return datetime.now().astimezone().isoformat(timespec="seconds")


def iso_to_epoch(ts):
    if not ts:
        return None
    try:
        t = datetime.fromisoformat(ts)
    except ValueError:
        return None
    if t.tzinfo is None:
        t = t.astimezone()
    return t.timestamp()


# ============================================================
# ★ 签名 —— 必须与节点侧 halib.verdict_sig() 逐字节一致
# ============================================================

def verdict_sig(token, node, verdict, ts, ttl, blind):
    """内容 = node | verdict | ts | ttl | blind

    ★ ts 用的是**即将原样发出去的**那个字符串，不重新格式化 ——
      两边拼出来的字节流才会完全相同。
    """
    content = "%s|%s|%s|%s|%s" % (
        node or "", verdict or "", ts or "", ttl if ttl is not None else "-",
        "1" if blind else "0")
    return hmac.new((token or "").encode("utf-8"),
                    content.encode("utf-8"), hashlib.sha256).hexdigest()


# ============================================================
# 状态文件的读写
# ============================================================

class Store(object):
    """仲裁节点的全部持久状态。**所有接口都从这里派生**（§5 M1.7 约束 1）。"""

    def __init__(self, conf):
        self.conf = conf

    def _path(self, name):
        return os.path.join(self.conf.state_dir, name)

    def _read_json(self, name, default):
        try:
            with open(self._path(name), encoding="utf-8-sig") as f:
                return json.load(f)
        except (OSError, ValueError):
            return default

    def _write_json(self, name, obj):
        d = self.conf.state_dir
        os.makedirs(d, exist_ok=True)
        tmp = self._path(name + ".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, indent=1)
        os.replace(tmp, self._path(name))

    # ---- 观测轮次（由 run-adapters.sh 写入）----
    def adapters(self):
        return self._read_json("adapters.json", {})

    # ---- 维护窗口 ----
    def maintenance(self):
        m = self._read_json("maintenance.json", {})
        if not m:
            return {}
        end = m.get("end_epoch") or 0
        if time.time() >= end:
            return {}          # ★ 自动过期，不存在"一扇常开的门"
        m["remaining_sec"] = int(end - time.time())
        return m

    def set_maintenance(self, minutes, reason, by):
        """开一个**全局**维护窗口。

        ★★ 参数里**没有 node** —— 这是刻意的。窗口一开就是"所有节点一律 deny"，
          没有对象、也没有"对象填错"这一类事故。而且**不许**给它加回带默认值的
          参数（例如 scope="global"）：万一部署时新旧文件混了，位置参数错位会被
          默认值**悄悄吞掉**，写出一份谁也看不懂的 maintenance.json。保持三个位置
          参数，混用时当场 TypeError —— 那才是我们要的失败方向。
        """
        max_sec = self.conf.getint("MAINT_WINDOW_MAX", 1800)
        sec = min(int(minutes * 60), max_sec)
        now = int(time.time())      # ★ 只取一次：取两次会让 start/end 差几微秒
        m = {"scope": "global",     # ★ 让文件自解释，也让"升级前留下的旧格式"
                                    #   文件（带 node、没有 scope）一眼可辨
             "start_epoch": now, "end_epoch": now + sec,
             "reason": reason, "by": by}
        self._write_json("maintenance.json", m)
        return m

    def clear_maintenance(self):
        try:
            os.remove(self._path("maintenance.json"))
        except OSError:
            pass

    # ---- 节点上报（§5 M1.4）----
    def reports(self):
        return self._read_json("reports.json", {})

    def set_report(self, node, payload):
        r = self.reports()
        r[node] = payload
        self._write_json("reports.json", r)


# ============================================================
# ★ 判定引擎（§5 M1.2）
# ============================================================

def judge_node(conf, store, node):
    """对节点 node 回答：「它现在能不能当主库？」

    返回一个 dict：
        verdict   'allow' / 'deny' / 'unknown'
        reason    一句话理由（★ 被拒时必须点名是哪个适配器挡的）
        blind     自检闸是否不过
        armed     观测引擎是否处于可工作状态
        age       证据年龄（秒），拿不到为 None
        evidence_ts
        adapters  该节点的适配器结果列表
    """
    ttl = conf.getint("VERDICT_TTL", 90)
    a = store.adapters()

    out = {"verdict": "unknown", "reason": "", "blind": False, "armed": False,
           "age": None, "evidence_ts": "", "adapters": []}

    # ---- 前置 0：观测引擎是否就绪 ----
    if not a:
        out["reason"] = ("仲裁节点尚未完成第一轮观测（%s 不存在）。"
                         % os.path.join(conf.state_dir, "adapters.json"))
        return out
    out["armed"] = True

    # ---- 前置 1：★ 自检闸（判据③ 的落地）----
    # 它必须排在所有判据之前：一个"看不见任何东西"的仲裁节点，
    # 会让每条判据都显示"通过"，然后发出一堆 allow。那不是缺少检查，
    # 是缺少"我能不能看见"这个前置。
    sc = a.get("selfcheck") or {}
    if not sc.get("ok"):
        out["blind"] = True
        out["reason"] = ("仲裁节点自身自检未通过：%s。"
                         "它此刻的观测不可采信，因此不能给出任何许可。"
                         % (sc.get("reason") or "未执行"))
        return out

    # ---- 前置 2：★ 维护窗口（全局）----
    # ★★ 窗口是**全局**的，也是**减权限**的操作：窗口一开，**所有**节点来要许可
    #    都拿到 deny。旧写法要对一个 IP（"对象节点"），而填错它的表现是
    #    "窗口开了机器照样被接管"（对象填错了）或"窗口开了却挡住了本该放过的
    #    机器"（对象是别人）—— 两种都**不报错**。去掉那个参数，就是从一次
    #    凌晨三点的动作里去掉一整类静默事故。
    #
    # ★ 为什么必须在这里（判定里）拦，而不是只在页面上显示：
    #   窗口的用途是「这台要计划重启，重启期间别抢」。
    #   如果它只是显示，那对端在计划重启的窗口里照常接管 ——
    #   值班人以为窗口已经把自动接管挡住了，实际没有。
    #   （需求 §5 M1.8 ⚠️ 与 R13 说的就是这件事：窗口期内**明知地放弃**
    #    自动接管，所以真故障必须走 ha-force.py。）
    #
    # ★★ 全局化的代价（明知并接受）：被维护的那台**自己也**拿不到许可 ——
    #    它计划内重启回来时，守卫会拒绝启动 PG，要有人跑 ha-force.py up。
    #    所以出口必须写进 reason 里：这是现场唯一看得见的一句话。
    #
    # ★ 它排在自检闸之后：自检不过时我们说「我们瞎了」，那是更根本的原因。
    # ★ 这里**不看 node**（这正是"一律 deny"的落地点）。副作用是安全的：
    #   升级瞬间，一条**旧格式**（带 node）的窗口文件读进来同样落到这一支，
    #   不会出现"升级把已经开着的窗口放空"的缺口。
    maint = store.maintenance()
    if maint:
        out["verdict"] = "deny"
        out["reason"] = ("维护窗口开启中（★ 全局，剩余 %d 秒）—— 窗口期内**所有**"
                         "节点一律不放行（只减权限）。★ 这是计划内维护，不是故障"
                         "判据：若 %s 确实该起来（计划重启已回来，或它是真故障），"
                         "在那台上跑 ha-force.py（它仍然查 VIP）。"
                         % (maint.get("remaining_sec", 0), node))
        return out

    # ---- 判据②：该节点的适配器证据 ----
    node_entry = (a.get("nodes") or {}).get(node)
    if not node_entry:
        out["reason"] = "本轮观测里没有节点 %s 的结果（adapters.json 可能不完整）。" % node
        return out

    results = node_entry.get("adapters") or []
    out["adapters"] = results
    if not results:
        out["reason"] = "节点 %s 这一轮没有跑任何适配器。" % node
        return out

    # ---- 判据④：新鲜度 = 全部证据里最旧的那一条 ----
    # ★ 它不属于任何适配器，所以**加任何适配器都不能放宽它**。
    epochs = [r.get("epoch") for r in results if r.get("epoch")]
    if not epochs:
        out["reason"] = "节点 %s 的证据缺少时间戳，无法确认新鲜度。" % node
        return out
    oldest = min(epochs)
    age = int(time.time() - oldest)
    out["age"] = age
    out["evidence_ts"] = [r.get("ts") for r in results
                          if r.get("epoch") == oldest][0] or ""
    if age > ttl:
        out["reason"] = ("证据已过期 %d 秒（> VERDICT_TTL=%d）—— "
                         "仲裁节点可能卡住了，按不可用处理。" % (age, ttl))
        return out

    # ---- ★ 证据组合：按强度分层，不是与门 ----
    #   ① 任何适配器返回 1（确证对端在服务）      → 拒绝   ← 最高优先级
    #   ② 任何【判据型】适配器返回 0（确证不在）  → 通过
    #   ③ 其余（否决型不否决、判据型返回 3）      → 通过（B 级判据，残余风险 = R1）
    #   ④ 没有 0、也没有 1，只有 2 和 3           → unknown → 拒绝
    #
    # ★ `3` 的位置：它**既不放行也不否决**，等价于"这个适配器是能用的，
    #   只是这一路观测回答不了这个问题"。所以它不该把判决推向任何一边，
    #   也不该计入退化（见 build_state 里的 DEGRADED_EVIDENCE）。
    denied = [r for r in results if r.get("rc") == 1]
    if denied:
        d = denied[0]
        out["verdict"] = "deny"
        out["reason"] = ("被 %s 拦住：%s"
                         % (d.get("name"), d.get("reason") or "对端仍在服务"))
        return out

    judges_ok = [r for r in results
                 if r.get("rc") == 0 and conf.is_judge_level(r.get("name") or "")]
    if judges_ok:
        j = judges_ok[0]
        out["verdict"] = "allow"
        out["reason"] = ("由判据型适配器 %s 确证对端不在服务：%s；证据年龄 %ds"
                         % (j.get("name"), j.get("reason") or "", age))
        return out

    # 到这里：没有 deny，也没有判据型的肯定。只剩"没说话"的（0/3）和"看不见"的（2）
    silent = [r for r in results if r.get("rc") in (2, 3)]
    if len(silent) == len(results):
        blind_ones = [r for r in silent if r.get("rc") == 2]
        noconc = [r for r in silent if r.get("rc") == 3]
        if blind_ones:
            out["reason"] = ("全部适配器都不可用（%s）—— 我们自己瞎了，"
                             "不能据此发放许可。"
                             % "、".join(r.get("name") or "?" for r in blind_ones))
        else:
            out["reason"] = ("所有适配器都看了，但都得出不结论（%s）—— "
                             "没有任何证据支持放行，不能据此发放许可。"
                             % "、".join(r.get("name") or "?" for r in noconc))
        return out

    veto_ok = [r for r in results if r.get("rc") == 0]
    if veto_ok:
        out["verdict"] = "allow"
        out["reason"] = ("全部否决型适配器都没有看到对端在服务（%s）；"
                         "证据年龄 %ds。★ 这是 B 级判据：网络类观测无法排除分区，"
                         "残余风险见 R1。"
                         % ("、".join(r.get("name") or "?" for r in veto_ok), age))
        return out

    out["reason"] = "证据组合无结论：没有任何适配器返回 0，也不是全都不可用。"
    return out


# ============================================================
# ★ 综合状态（§5 M1.6 / M1.7）
# ============================================================

def build_state(conf, store):
    """算出**唯一的内部状态对象**。/state 与 /metrics 都从它派生。

    ★ 约束 1：两个端点必须从同一个内部状态对象派生 —— 两份实现迟早给出两个答案。
    """
    conf.maybe_reload()
    a = store.adapters()
    maint = store.maintenance()
    reports = store.reports()
    nodes = [n for n in conf.nodes if n]
    ttl = conf.getint("VERDICT_TTL", 90)

    stale_reports = {n: r for n, r in reports.items()
                     if (time.time() - (r.get("_recv_epoch") or 0)) > ttl}

    per_node = {}
    for n in nodes:
        per_node[n] = judge_node(conf, store, n)

    sc = a.get("selfcheck") or {}
    blind = not sc.get("ok", False) if a else False
    armed = bool(a)
    run_age = int(time.time() - a["run_epoch"]) if a.get("run_epoch") else None

    # ---- 原始量：谁在服务、谁在复制 ----
    vip_holder = (a.get("vip") or {}).get("holder_mac") or "unknown"
    vip_by = (a.get("vip") or {}).get("by") or "unknown"

    pg_reports = {}
    for n in nodes:
        r = reports.get(n) or {}
        if n in stale_reports:
            # ★ 过期的上报整条作废（含 health）—— 半新半旧的快照比没有更坏。
            #   页面与 /metrics 据此显示为"没数据"，而不是上一个周期的残留值。
            pg_reports[n] = {"pg": "stale", "vip_here": None, "age": int(
                time.time() - (r.get("_recv_epoch") or 0)), "health": {}}
        else:
            pg_reports[n] = {
                "pg": r.get("pg") or "unknown",
                "role": r.get("role") or "unknown",
                "vip_here": r.get("vip_here"),
                "action": r.get("action") or "none",
                "age": (int(time.time() - r["_recv_epoch"])
                        if r.get("_recv_epoch") else None),
                "detail": r.get("detail") or "",
                # ★ 节点自报的健康快照（未采信，见 §5 M1.4）。原样透传，
                #   不在这里加工 —— 加工过的东西和 /metrics 会分叉。
                "health": r.get("health") or {}}

    serving = [n for n in nodes if pg_reports.get(n, {}).get("pg") == "primary"
               and pg_reports.get(n, {}).get("vip_here")]
    primary_reports = [n for n in nodes if pg_reports.get(n, {}).get("pg") == "primary"]
    vip_holders = [n for n in nodes if pg_reports.get(n, {}).get("vip_here")]

    # ---- 备库是否**真的在复制**（不是"还活着"）----
    repl = a.get("replication") or {}
    standby_ok = repl.get("streaming") is True
    standby_slot = repl.get("slot") or ""
    standby_note = repl.get("detail") or ""

    # ---- 坏掉的适配器（DEGRADED_EVIDENCE）----
    # ★ 只收 rc == 2。rc == 3 是"这个适配器在正常工作，只是这一路观测
    #   回答不了这个问题"，把它算成退化会造成常年误报，最后没人看这个状态。
    degraded = []
    for n in nodes:
        for r in (per_node[n].get("adapters") or []):
            if r.get("rc") == 2:
                degraded.append({"node": n, "name": r.get("name"),
                                 "reason": r.get("reason"),
                                 "unavailable_rounds": r.get("unavailable_rounds", 1)})

    # ---- "看了，但看不出"的适配器：不上报退化，但要在 /state 里看得见 ----
    no_conc = []
    for n in nodes:
        for r in (per_node[n].get("adapters") or []):
            if r.get("rc") == 3:
                no_conc.append({"node": n, "name": r.get("name"),
                                "reason": r.get("reason")})

    # ---- 综合状态：按 STATE_ORDER 取第一个命中的 ----
    def pick():
        if blind:
            return "BLIND", ("自检闸未通过：%s" % (sc.get("reason") or ""))
        # SPLIT_BRAIN：VIP 被两个 MAC 应答，或两台都自报主库
        if len(primary_reports) >= 2:
            return "SPLIT_BRAIN", ("两台都自报 PostgreSQL 主库（%s）—— 数据正在分叉"
                                   % "、".join(primary_reports))
        if len(vip_holders) >= 2:
            return "SPLIT_BRAIN", ("两台都自报持有 VIP（%s）—— 客户端会打到两台"
                                   % "、".join(vip_holders))
        if (a.get("vip") or {}).get("answerers") and \
                len((a.get("vip") or {}).get("answerers") or []) >= 2:
            return "SPLIT_BRAIN", ("VIP 被多个 MAC 应答：%s"
                                   % "、".join((a.get("vip") or {}).get("answerers")))
        # NO_PRIMARY：没有任何主库在服务
        if nodes and not primary_reports:
            return "NO_PRIMARY", ("VIP %s 上没有任何节点自报主库 —— 监控数据此刻正在丢失"
                                  % (conf.get("VIP") or ""))
        if maint:
            return "MAINTENANCE", ("维护窗口开启中（★ 全局），剩余 %d 秒 —— "
                                   "期间**任何**节点都不会被自动接管；"
                                   "计划重启的那台要用 ha-force.py 起回来。"
                                   % maint.get("remaining_sec", 0))
        if nodes and not standby_ok:
            return "NO_STANDBY", ("有一台在服务，但没有备库在真实复制：%s"
                                  % (standby_note or "（未取到复制状态）"))
        if degraded:
            return "DEGRADED_EVIDENCE", ("有 %d 个适配器不可用：%s"
                                         % (len(degraded),
                                            "、".join(sorted(set(d["name"] or "?"
                                                                for d in degraded)))))
        return "OK", "一台持 VIP 在服务，另一台在真实跟随"

    composite, composite_reason = pick()

    return {
        "state_schema_version": SCHEMA_VERSION,
        "composite": composite,
        "composite_severity": SEVERITY.get(composite, "未知"),
        "composite_reason": composite_reason,
        "blind": blind,
        "armed": armed,
        "observed_at": a.get("run_at") or "",
        "observed_age_sec": run_age,
        "verdict_ttl": ttl,
        "vip": {
            "address": conf.get("VIP") or "",
            "holder_mac": vip_holder,
            "reported_by": vip_by,
            "answerers": (a.get("vip") or {}).get("answerers") or [],
        },
        # ★ 页面横幅「业务在哪台」用的就是这一份 —— 与 pick() 里的
        #   primary_reports / vip_holders 同源，别在渲染处另算一遍。
        "serving": serving,
        "selfcheck": {
            "ok": bool(sc.get("ok")),
            "reason": sc.get("reason") or "",
            "targets": sc.get("targets") or [],
        },
        "replication": {
            "streaming": standby_ok,
            "slot": standby_slot,
            "detail": standby_note,
        },
        "maintenance": {
            "active": bool(maint),
            # ★ 没有 node 字段：窗口是全局的，判定侧只认"有没有窗口"。
            #   所以**旧格式**文件（带 node）在这里也报 global —— 那是对行为的
            #   真实描述（judge_node 前置 2 同样不看 node）。
            "scope": "global" if maint else "",
            "remaining_sec": maint.get("remaining_sec", 0),
            "reason": maint.get("reason") or "",
            "by": maint.get("by") or "",
        },
        "nodes": {n: {
            "verdict": per_node[n].get("verdict"),
            "reason": per_node[n].get("reason"),
            "age_sec": per_node[n].get("age"),
            "evidence_ts": per_node[n].get("evidence_ts"),
            "adapters": per_node[n].get("adapters") or [],
            "report": pg_reports.get(n) or {},
        } for n in nodes},
        "degraded_adapters": degraded,
        "no_conclusion_adapters": no_conc,
        "adapters_configured": a.get("configured") or [],
    }


# ============================================================
# /metrics —— 扁平 key value（★ 给 Zabbix 与 shell）
# ============================================================

def to_metrics(st):
    """★ 从**同一个**内部状态对象派生（约束 1）。

    形状：每行 `key value`。Zabbix 用 HTTP agent 采，一个监控项就是一次
    字符串查找；凌晨三点排障 `curl /metrics | grep standby` 就看完了。

    ★ 字段集合**只增不减**（约束 3）—— Zabbix 监控项绑死在字段名上，
      改名 = 静默丢监控。改名不是"重命名"，是"先加新的、等监控项切完再删旧的"。
    """
    L = []
    L.append("state_schema_version %s" % st["state_schema_version"])
    L.append("composite %s" % st["composite"])
    L.append("composite_severity %s" % st["composite_severity"])
    L.append("blind %d" % (1 if st["blind"] else 0))
    L.append("armed %d" % (1 if st["armed"] else 0))
    L.append("observed_age_sec %s" % (st["observed_age_sec"]
                                      if st["observed_age_sec"] is not None else -1))
    L.append("verdict_ttl %s" % st["verdict_ttl"])
    L.append("vip %s" % (st["vip"]["address"] or "none"))
    L.append("vip_holder_mac %s" % (st["vip"]["holder_mac"] or "unknown"))
    L.append("vip_answerers %d" % len(st["vip"]["answerers"]))
    L.append("selfcheck_ok %d" % (1 if st["selfcheck"]["ok"] else 0))
    L.append("replication_streaming %d" % (1 if st["replication"]["streaming"] else 0))
    L.append("replication_slot %s" % (st["replication"]["slot"] or "none"))
    L.append("maintenance_active %d" % (1 if st["maintenance"]["active"] else 0))
    # ★★ 字段名**保留**（约束 3：只增不减 —— 改名 = 静默丢 Zabbix 监控项）。
    #    窗口现在是**全局**的，所以取值是 all（开着）/ none（没开）。
    #    ★ 要紧的是**开窗口时不能取 `none`**：`none` 在旧语义里就是"没开窗口"，
    #      撞在一起会把两件相反的事写成同一个值，监控上一眼看不出来。
    L.append("maintenance_node %s"
             % ("all" if st["maintenance"]["active"] else "none"))
    L.append("maintenance_remaining_sec %s" % st["maintenance"]["remaining_sec"])
    L.append("degraded_adapters %d" % len(st["degraded_adapters"]))
    L.append("no_conclusion_adapters %d" % len(st["no_conclusion_adapters"]))
    L.append("nodes_configured %d" % len(st["nodes"]))
    for n, d in st["nodes"].items():
        suf = n.replace(".", "_")
        L.append("node_%s_verdict %s" % (suf, d["verdict"] or "unknown"))
        L.append("node_%s_age_sec %s" % (suf, d["age_sec"]
                                         if d["age_sec"] is not None else -1))
        L.append("node_%s_pg %s" % (suf, (d["report"] or {}).get("pg") or "unknown"))
        L.append("node_%s_role %s" % (suf, (d["report"] or {}).get("role") or "unknown"))
        L.append("node_%s_vip_here %s" % (
            suf, {True: 1, False: 0}.get((d["report"] or {}).get("vip_here"), -1)))
        # ---- 节点自报的健康快照（★ 未采信：它是节点自己说的，不进判定）----
        h = (d["report"] or {}).get("health") or {}
        # 上报本身的年龄（★ 与上面 age_sec 的"证据年龄"是两回事：那个是仲裁
        # 自己观测的时刻，这个是对端自报到达的时刻）。它能爬到 ttl 之前就
        # 先涨起来 —— "这台节点快不上报了"比"这台节点已经不上报了"有用。
        L.append("node_%s_report_age_sec %s" % (
            suf, ((d["report"] or {}).get("age")
                  if (d["report"] or {}).get("age") is not None else -1)))
        L.append("node_%s_timeline %s" % (suf, h.get("timeline", -1)))
        # ★ 业务库占用（字节）。节点侧与其余八项同一条 SQL 取回 —— 不加 fork。
        L.append("node_%s_db_size_bytes %s" % (suf, h.get("db_size", -1)))
        L.append("node_%s_superseded %d" % (suf, 1 if h.get("superseded") else 0))
        L.append("node_%s_wal_status %s" % (suf, h.get("wal_status") or "unknown"))
        L.append("node_%s_wal_lag_bytes %s" % (suf, h.get("wal_lag", -1)))
        L.append("node_%s_wal_sender %s" % (suf, h.get("wal_sender") or "unknown"))
        L.append("node_%s_senders %s" % (suf, h.get("senders", -1)))
        L.append("node_%s_sender_states %s" % (
            suf, h.get("sender_states") or "unknown"))
        L.append("node_%s_sender_lag_bytes %s" % (suf, h.get("sender_lag", -1)))
        for role_key in sorted(h.get("svc") or {}):
            sd = (h.get("svc") or {}).get(role_key) or {}
            L.append("node_%s_svc_%s_active %s" % (
                suf, role_key, sd.get("active") or "unknown"))
            L.append("node_%s_svc_%s_load %s" % (
                suf, role_key, sd.get("load") or "unknown"))
        for ad in (d["adapters"] or []):
            key = (ad.get("name") or "?").replace(".", "_").replace("-", "_")
            L.append("node_%s_adapter_%s_rc %s" % (suf, key, ad.get("rc")))
            L.append("node_%s_adapter_%s_age_sec %s" % (
                suf, key, ad.get("age_sec", -1)))
    return "\n".join(L) + "\n"


# ============================================================
# 节点自报的健康快照 → 页面上一行（★ 自报，未采信）
# ============================================================

_SVC_LABEL = {"pg": "PG", "zabbix_server": "Zabbix Server",
              "zabbix_agent": "Zabbix Agent"}


def _svc_cls(sd):
    """服务状态的着色档。★ 四档而不是两档：「没装」不是「挂了」。"""
    load = (sd.get("load") or "").lower()
    act = (sd.get("active") or "").lower()
    if load == "not-found":
        return "st-na"                      # 这台机器上没有这个单元
    if act == "active":
        return "st-ok"
    if act in ("activating", "deactivating", "reloading"):
        return "st-warn"
    if act in ("failed", "inactive"):
        return "st-bad"
    return "st-na"


def health_line(rep, esc):
    """把节点自报的健康快照渲染成一行 HTML。返回 '' 表示这份上报里没有 health
    （老版本节点，或这条上报已经过期 —— 见 build_state 的 stale_reports）。
    """
    h = (rep or {}).get("health") or {}
    if not h:
        return ""
    bits = []

    for k in ("pg", "zabbix_server", "zabbix_agent"):
        sd = (h.get("svc") or {}).get(k) or {}
        if not sd:
            continue
        txt = "%s %s" % (_SVC_LABEL.get(k, k), sd.get("active") or "unknown")
        load = (sd.get("load") or "").lower()
        if load and load != "loaded":
            # ★ LoadState 要带出来：is-active 口径下「没装这个单元」与
            #   「装了但停着」都显示 inactive —— 排障时这两者必须分得开。
            txt += "（%s）" % load
        bits.append("<span class='%s'>%s</span>" % (_svc_cls(sd), esc(txt)))

    if h.get("timeline", -1) >= 0:
        bits.append("时间线 %s" % h["timeline"])

    if h.get("pg") == "standby":
        st = (h.get("wal_status") or "").strip()
        s = "接收 %s ← %s" % (st or "（接收器没在跑）",
                             h.get("wal_sender") or "?")
        if h.get("wal_lag", -1) >= 0:
            s += "，未回放 %d B" % h["wal_lag"]
        bits.append("<span class='%s'>%s</span>"
                    % ("st-ok" if st == "streaming" else "st-bad", esc(s)))
    elif h.get("pg") == "primary":
        n = h.get("senders", -1)
        if n >= 0:
            s = "下游备库 %d 个" % n
            if h.get("sender_states"):
                s += "（%s）" % h["sender_states"]
            if h.get("sender_lag", -1) >= 0:
                s += "，最落后 %d B" % h["sender_lag"]
            bits.append("<span class='%s'>%s</span>"
                        % ("st-ok" if n > 0 else "st-bad", esc(s)))

    if h.get("superseded"):
        bits.append("<span class='st-bad'>★ 已被取代（superseded）</span>")

    return ("<tr class='hlth'><td></td><td colspan=5>"
            "<span class='tag'>自报</span> %s</td></tr>" % "　·　".join(bits))


# ============================================================
# 看板 —— 灯 / 箭头 / 建议操作（★ 全是渲染，不产生新判据）
# ============================================================
# 结论只有 build_state 那一份：这里只决定"怎么画"。
# 颜色、文案可以随展示需要改，但"谁在服务、复制通没通"不许在这里再算一遍
# —— 两份实现迟早给出两个答案（build_state 的约束 1，同款理由）。


def human_bytes(n):
    """字节数 → 人读。取不到（None / 负数）给「—」—— 不把"不知道"编成 0。"""
    try:
        n = int(n)
    except (TypeError, ValueError):
        return "—"
    if n < 0:
        return "—"
    v = float(n)
    for u in ("B", "KB", "MB", "GB", "TB"):
        if v < 1024 or u == "TB":
            return ("%d %s" % (v, u)) if u == "B" else ("%.1f %s" % (v, u))
        v /= 1024.0
    return "%d B" % n


def node_light(rep, blind=False, split=False):
    """这台亮什么灯：绿=主库、蓝=备库、红=状态未知。返回 (类名, 角色文字)。

    ★ 红＝"看不清"，不是"坏了"：没上报 / 上报过期 / 两台都自报主库 /
      仲裁自己 blind，全都归到这里 —— 给一个看着确定的颜色比给红色更坏。
    """
    pg = ((rep or {}).get("pg") or "").strip()
    if blind or split:
        return "red", "状态未知"
    if pg == "primary":
        return "green", "主库"
    if pg == "standby":
        return "blue", "备库"
    if pg == "stale":
        return "red", "上报过期"
    return "red", "状态未知"


def repl_summary(rep):
    """一条复制关系（措辞与 health_line 同源）。返回 (文字, 是否健康)。"""
    h = (rep or {}).get("health") or {}
    pg = (rep or {}).get("pg") or ""
    if pg == "standby":
        st = (h.get("wal_status") or "").strip()
        s = "接收 %s ← %s" % (st or "（接收器没在跑）", h.get("wal_sender") or "?")
        if h.get("wal_lag", -1) >= 0:
            s += "，未回放 %s" % human_bytes(h.get("wal_lag"))
        return s, (st == "streaming")
    if pg == "primary":
        n = h.get("senders", -1)
        s = "下游备库 %s 个" % (n if n >= 0 else "?")
        if h.get("sender_states"):
            s += "（%s）" % h["sender_states"]
        if h.get("sender_lag", -1) >= 0:
            s += "，最落后 %s" % human_bytes(h.get("sender_lag"))
        return s, (n > 0)
    return "—", False


def svc_dots(rep, esc):
    """PG / Zabbix Server / Zabbix Agent 三个小点（配色沿用 st-* 四档）。"""
    h = (rep or {}).get("health") or {}
    out = []
    for k, lab in (("pg", "PG"), ("zabbix_server", "ZS"), ("zabbix_agent", "ZA")):
        sd = (h.get("svc") or {}).get(k) or {}
        cls = _svc_cls(sd) if sd else "st-na"
        title = "%s：%s" % (_SVC_LABEL.get(k, k), sd.get("active") or "无数据")
        out.append("<span class='svc' title='%s'>%s<i class='sdot %s'></i></span>"
                   % (esc(title), esc(lab), cls))
    return "".join(out)


def node_card(ip, d, blind, split, esc):
    """一台机器的卡片：灯 + 角色 + 库大小 + 复制一行 + 三个服务点 + 上报年龄。"""
    rep = d.get("report") or {}
    h = rep.get("health") or {}
    cls, role = node_light(rep, blind, split)
    badge = ("<div class='badge'>★ 业务在这台（持 VIP）</div>"
             if rep.get("vip_here") is True else "")
    rs, rs_ok = repl_summary(rep)
    rs_cls = "st-bad" if (not rs_ok and cls in ("green", "blue")) else ""
    age = rep.get("age")
    return ("<div class='card %s'>"
            "<div class='lamp %s'><i></i></div>"
            "<div class='ip'>%s</div>"
            "<div class='role %s'>%s</div>"
            "%s"
            "<div class='kv2'>库大小 <b>%s</b></div>"
            "<div class='kv2 %s'>%s</div>"
            "<div class='svcs'>%s</div>"
            "<div class='kv2'>上报 <b>%s</b></div>"
            "</div>"
            % (cls, cls, esc(ip), cls, esc(role), badge,
               esc(human_bytes(h.get("db_size"))), rs_cls, esc(rs),
               svc_dots(rep, esc),
               esc("%s 秒前" % age) if age is not None else "—"))


def wire(flow, state, label):
    """两台之间那条线。flow: 'r'/'l'（流向）；state: 'ok'/'bad'/'none'。

    ★ 无缝滚动靠「一格一格位移」：每个箭头是固定宽（30px）的 span，
      整条动画正好移一格 —— 图案是周期的，看不出接缝。
      红色/灰色时**停住**：停下来的箭头本身就是"没在流"的信号。
    """
    ch = "▸" if flow == "r" else "◂"
    track = ("<span>%s</span>" % ch) * 40
    return ("<div class='wirewrap'>"
            "<div class='wire %s %s'><div class='track'>%s</div></div>"
            "<div class='wirelab'>%s</div></div>"
            % (state, flow, track, label))


_ADVICE_STEPS = """<ol class='steps'>
<li>两台<b>各</b>跑一次 <code>sudo /opt/simplified-ha/ha-status.py</code>
 —— 先看清全局，不要只看一台。</li>
<li>到备机那台查值守在不在跑（"等一轮"的前提是它在跑）：<br>
<code>systemctl status zbx-ha-agent.timer</code>
<code>journalctl -u zbx-ha-agent -n 30 --no-pager</code></li>
<li>查接收器和复制槽（槽名 = <code>slot_</code> + 机器 IP 末段，如 slot_221）：<br>
<b>备机</b>：<code>sudo -u postgres psql -tAc "SELECT status||' / slot='||COALESCE(slot_name,'【空！】')
FROM pg_stat_wal_receiver;"</code><br>
<b>对端主库</b>：<code>sudo -u postgres psql -c "SELECT slot_name, active
FROM pg_replication_slots;"</code><br>
接收器 0 行 / 槽恒为 active=f —— 先看 04 §2.3、§2.9 那两个坑。</li>
<li>确实要重新归位时（★ <code>--rebuild</code> 是危险动作：整库重传、按小时计停机、
磁盘要够）：<br>
<code>sudo /opt/simplified-ha/ha-rejoin.py --rebuild --dry-run</code>
 ← 先跑这一条看输出，确认无误再去掉 <code>--dry-run</code></li>
<li>★ 不要在两台上同时动手；有维护窗口时两台都是 deny（04 §8）。</li>
</ol>"""


def standby_advice(st, esc):
    """备机没有正常工作时的「建议操作」（<details> 展开）。返回 '' = 不显示。

    ★ 只给步骤，**不执行任何东西** —— 本节点永久只读，
      页面刻意不提供任何会改变状态的按钮（00 §6 第 5 条、10 §2.1）。
    """
    if st["blind"] or st["composite"] == "SPLIT_BRAIN":
        # 这两类故障的建议不是"修备库"：blind 走 04 §9，双主走 04 §6。
        # 强塞一份备库建议反而是误导。
        return ""
    rep = {n: (d.get("report") or {}) for n, d in st["nodes"].items()}
    if not any(r.get("pg") == "primary" for r in rep.values()):
        return ""            # 连主库都没自报在服务 —— 那是另一类故障（04 §6.5）
    why = []
    if st["composite"] == "NO_STANDBY":
        why.append("仲裁节点看不到备库在真实复制")
    for n in sorted(rep):
        r = rep[n]
        h = r.get("health") or {}
        if r.get("pg") == "standby":
            w = (h.get("wal_status") or "").strip()
            if w != "streaming":
                why.append("%s 自报备库，但接收器没在跑（%s）" % (n, w or "空"))
        elif r.get("pg") == "primary" and h.get("senders") == 0:
            why.append("%s 自报主库，但下游备库 0 个" % n)
        elif r.get("pg") in ("stale", "unknown"):
            why.append("%s 连上报都没到（%s）" % (n, r.get("pg")))
    why = [w for i, w in enumerate(why) if w not in why[:i]]
    if not why:
        return ""
    return ("<details class='advice'><summary>"
            "⚠ 备机没有正常工作 —— 点这里看建议操作"
            "（本页只读，不会替你执行）</summary>"
            "<p class='why'>判据（都是上面的观测或自报）：%s</p>%s</details>"
            % (esc("；".join(why)), _ADVICE_STEPS))


# ============================================================
# HTTP
# ============================================================

class Handler(BaseHTTPRequestHandler):
    server_version = "zbx-arbiter"
    sys_version = ""
    protocol_version = "HTTP/1.1"

    # 由 serve() 注入
    conf = None
    store = None

    # ---------- 工具 ----------
    def _client_ip(self):
        return self.client_address[0]

    def _allowed(self):
        allow = self.conf.allow_from
        if not allow:
            # ★ 白名单为空 = 谁都不许。安全侧的缺省必须是"拒绝"，
            #   而不是"允许所有人"。装完必须填这一项。
            return False
        return self._client_ip() in allow

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _json(self, code, obj):
        self._send(code, json.dumps(obj, ensure_ascii=False, indent=1))

    def _err(self, code, msg):
        self._send(code, msg + "\n", "text/plain; charset=utf-8")

    def log_message(self, fmt, *args):
        # 默认实现往 stderr 写一行一条；我们需要它进 journal，但不要刷屏
        log("%s %s" % (self._client_ip(), fmt % args))

    # ---------- 路由 ----------
    def do_GET(self):
        u = urllib.parse.urlparse(self.path)
        q = urllib.parse.parse_qs(u.query)

        # ★ 来源 IP 白名单是**唯一的访问控制**（端点不认证，见 §5 M1.5）。
        #   这里必须排在所有路由之前，包括静态分发。
        if not self._allowed():
            log("拒绝来自 %s 的请求（不在 ARBITER_ALLOW_FROM 里）: %s"
                % (self._client_ip(), self.path))
            return self._err(403, "来源 %s 不在允许清单内。" % self._client_ip())

        if u.path == "/verdict":
            return self.handle_verdict(q)
        if u.path == "/state":
            return self.handle_state()
        if u.path == "/metrics":
            return self.handle_metrics()
        if u.path == "/health":
            return self.handle_health()
        if u.path == "/":
            return self.handle_page()
        if u.path == "/files" or u.path.startswith("/files/"):
            return self.handle_files(u.path)
        return self._err(404, "没有这个端点。可用：/verdict /state /metrics /health /files/")

    def do_POST(self):
        u = urllib.parse.urlparse(self.path)
        if not self._allowed():
            return self._err(403, "来源 %s 不在允许清单内。" % self._client_ip())
        if u.path == "/report":
            return self.handle_report()
        return self._err(404, "只有 /report 接受 POST。")

    # ---------- /verdict ----------
    def handle_verdict(self, q):
        node = (q.get("node") or [""])[0].strip()
        if not node:
            return self._err(400, "缺少 node 参数：/verdict?node=192.168.2.222")
        if node not in self.conf.nodes:
            return self._err(400, "node=%s 不是本仲裁节点配置的两台之一。" % node)

        j = judge_node(self.conf, self.store, node)
        peer = [n for n in self.conf.nodes if n and n != node]
        peer = peer[0] if peer else ""

        a = self.store.adapters()
        ts = now_iso()
        ttl = self.conf.getint("VERDICT_TTL", 90)
        blind = bool(j["blind"])
        verdict = j["verdict"]

        vip_info = a.get("vip") or {}
        peer_entry = (a.get("nodes") or {}).get(peer) or {}
        body = {
            "ts": ts,
            "ttl": ttl,
            "self": {"node": node, "verdict": verdict, "reason": j["reason"],
                     "evidence_ts": j["evidence_ts"], "age_sec": j["age"]},
            "peer": {"node": peer,
                     # ★ 只是观测值。它**不是**判据 ——
                     #   "对端不在服务" ≠ "对端不可达"，健康的备库是可达但不在服务的。
                     "alive": peer_entry.get("alive"),
                     "vip_holder": vip_info.get("holder_mac") or "none",
                     "vip_held_by": vip_info.get("by") or "unknown"},
            "adapters": j["adapters"],
            "armed": j["armed"],
            "blind": blind,
        }
        body["sig"] = verdict_sig(self.conf.token, node, verdict, ts, ttl, blind)
        return self._json(200, body)

    # ---------- /state ----------
    def handle_state(self):
        st = build_state(self.conf, self.store)
        # ★ 只读接口，但节点侧需要知道仲裁节点看到的 VIP 是不是和自己一样（R15）。
        #   这里回显**配置里的** VIP，供节点做三份一致性比对。
        st["config"] = {"vip": self.conf.get("VIP") or "",
                        "nodes": [n for n in self.conf.nodes if n]}
        # 维护窗口的命令（★ 见 M1.8：动作是本地 CLI，不是 HTTP 端点）
        # ★ 窗口是全局的，没有"对象节点"参数了；**哪一台**只能写进 --reason，
        #   否则事后没人说得清这个窗口当初是给谁开的。
        st["maintenance"]["how_to_open"] = (
            "sudo /opt/zbx-arbiter/arbiter-window.py open --minutes 30 "
            "--reason '221 内核升级'")
        return self._json(200, st)

    # ---------- /metrics ----------
    def handle_metrics(self):
        st = build_state(self.conf, self.store)
        return self._send(200, to_metrics(st), "text/plain; charset=utf-8")

    # ---------- /health（给节点侧的配置一致性校验用，最小形状）----------
    def handle_health(self):
        a = self.store.adapters()
        return self._json(200, {
            "ok": True,
            "ts": now_iso(),
            "vip": self.conf.get("VIP") or "",
            "nodes": [n for n in self.conf.nodes if n],
            "observed_age_sec": (int(time.time() - a["run_epoch"])
                                 if a.get("run_epoch") else None),
            "composite": build_state(self.conf, self.store)["composite"],
        })

    # ---------- /files（★ 裸奔，理由见 §5 M1.5）----------
    def handle_files(self, path):
        dist = (self.conf.get("DIST_DIR") or "/srv/zbx-ha-dist").strip()
        rel = path[len("/files"):].lstrip("/")
        if not rel:
            try:
                items = sorted(os.listdir(dist))
            except OSError as e:
                return self._err(500, "分发目录读不到: %s" % e)
            lines = ["分发目录 %s" % dist, ""]
            for i in items:
                full = os.path.join(dist, i)
                lines.append("  %-40s %10d  %s" % (
                    i, os.path.getsize(full),
                    datetime.fromtimestamp(os.path.getmtime(full)).strftime("%F %T")))
            lines += ["", "下载：GET /files/<文件名>",
                      "★ 这里没有任何凭据 —— 连密文都没有。模板里的密码字段一律留空。"]
            return self._send(200, "\n".join(lines) + "\n",
                              "text/plain; charset=utf-8")

        # ★ 目录穿越防护：解析后必须仍在 dist 之内
        full = os.path.realpath(os.path.join(dist, rel))
        if not full.startswith(os.path.realpath(dist) + os.sep):
            return self._err(403, "路径越界。")
        if not os.path.isfile(full):
            return self._err(404, "没有这个文件：%s" % rel)
        ctype = ("application/gzip" if full.endswith(".gz")
                 else "application/octet-stream")
        try:
            with open(full, "rb") as f:
                data = f.read()
        except OSError as e:
            return self._err(500, "读文件失败: %s" % e)
        return self._send(200, data, ctype)

    # ---------- /report ----------
    def handle_report(self):
        try:
            n = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(n).decode("utf-8", "replace")
            d = json.loads(raw)
        except Exception as e:
            return self._err(400, "报文不是合法 JSON: %s" % e)

        node = (d.get("node") or "").strip()
        if node not in self.conf.nodes:
            return self._err(400, "node=%s 不是本仲裁节点配置的两台之一。" % node)

        # 验签：上报不参与判定，所以验签失败**不拒绝**，但要留痕告警 ——
        # 一条来历不明的"我持有 VIP"如果被当成事实展示，就是误导运维。
        content = "%s|%s|%s|%s|%s" % (d.get("node") or "", d.get("role") or "",
                                      d.get("pg") or "", d.get("ts") or "",
                                      d.get("action") or "")
        expect = hmac.new(self.conf.token.encode("utf-8"),
                          content.encode("utf-8"), hashlib.sha256).hexdigest()
        if not hmac.compare_digest((d.get("sig") or ""), expect):
            log("★ 收到来自 %s 的 /report，但签名不匹配 —— 已记录但不采信：%s"
                % (self._client_ip(), d))

        d["_recv_epoch"] = int(time.time())
        d["_recv_from"] = self._client_ip()
        # ★ 写不下去要**明确**回一个 500，而不是让异常冒到 socketserver。
        #   不接的话连接会被直接掐断，节点侧拿到的是
        #   "Remote end closed connection without response" —— 那看起来像网络问题。
        #   实际多半是状态目录权限不对：本进程以 zbxarb 运行，要在这里写
        #   reports.json，而目录曾经被建成 root:zbxarb 750（组没有 w）。
        try:
            self.store.set_report(node, d)
        except OSError as e:
            log("★ /report 写不进状态目录，这一条没有存下: %s" % e)
            return self._err(500, "写状态失败：%s" % e)
        return self._json(200, {"ok": True, "ts": now_iso()})

    # ---------- / 页面 ----------
    def handle_page(self):
        st = build_state(self.conf, self.store)
        esc = lambda s: (str(s).replace("&", "&amp;").replace("<", "&lt;")
                         .replace(">", "&gt;"))
        c = st["composite"]
        color = {"OK": "#2e7d32", "MAINTENANCE": "#616161",
                 "DEGRADED_EVIDENCE": "#ef6c00", "NO_STANDBY": "#c62828",
                 "BLIND": "#c62828", "NO_PRIMARY": "#b71c1c",
                 "SPLIT_BRAIN": "#b71c1c"}.get(c, "#333")

        rows = []
        for n, d in st["nodes"].items():
            rep = d["report"] or {}
            rows.append(
                "<tr><td>%s</td><td><b>%s</b></td><td>%s</td><td>%s</td>"
                "<td>%s</td><td>%s</td></tr>" % (
                    esc(n), esc(d["verdict"]),
                    esc(rep.get("pg") or "?"), esc(rep.get("role") or "?"),
                    {True: "是", False: "否"}.get(rep.get("vip_here"), "?"),
                    esc("%ss" % d["age_sec"] if d["age_sec"] is not None else "?")))

            hl = health_line(rep, esc)
            if hl:
                rows.append(hl)

            for ad in (d["adapters"] or []):
                rows.append(
                    "<tr class='ad'><td></td><td colspan=5><span class='rc%d'>rc=%s</span> "
                    "%s — %s</td></tr>" % (
                        ad.get("rc") if ad.get("rc") in (0, 1, 2, 3) else 2,
                        esc(ad.get("rc")), esc(ad.get("name")),
                        esc(ad.get("reason"))))

        mnt = st["maintenance"]
        mnt_html = ""
        if mnt["active"]:
            mnt_html = ("<p class='warn'>★ 维护窗口开启中（<b>全局</b>），剩余 "
                        "<b>%d</b> 秒。窗口期内<b>所有</b>节点一律 deny ——"
                        "下表两台都会是 deny。<b>只减权限</b>：它只会把一次接管"
                        "推迟到窗口结束，不会让谁更容易通过。<br>"
                        "计划内重启的那台回来时守卫会拒绝启动：在那台上跑 "
                        "<code>ha-force.py up</code>。</p>"
                        % mnt["remaining_sec"])

        # ---- 看板：业务在哪台 + 两张卡 + 连线 ----
        nodes_order = sorted(st["nodes"].keys())
        per = {n: (st["nodes"][n].get("report") or {}) for n in nodes_order}
        split = (c == "SPLIT_BRAIN")
        prim = [n for n in nodes_order if per[n].get("pg") == "primary"]
        serving = [n for n in (st.get("serving") or [])]

        vipaddr = esc(st["vip"]["address"] or "?")
        if st["blind"]:
            vip_txt = ("业务（VIP %s）：<b>仲裁自己 blind，此刻看不清谁在服务</b>"
                       " —— 按 04 §9 查观测链路" % vipaddr)
            vip_cls = "vbad"
        elif split or len(serving) >= 2 or len(prim) >= 2:
            # ★ 这一支必须排在"正常在服务"前面：双主时 serving 里会有**两台**，
            #   否则横幅会平静地写成"业务当前在 221、222"—— 恰恰是最坏的事。
            vip_txt = ("业务（VIP %s）：<b>两台都自报在服务</b> —— "
                       "★ 立刻人工介入，按 04 §6 处置" % vipaddr)
            vip_cls = "vbad"
        elif serving:
            vip_txt = "业务（VIP %s）当前在 <b>%s</b>" % (
                vipaddr, esc("、".join(serving)))
            vip_cls = ""
        else:
            vip_txt = ("业务（VIP %s）：<b>没有节点自报在服务</b>"
                       % vipaddr)
            vip_cls = "vbad"

        cards = [node_card(n, st["nodes"][n], st["blind"], split, esc)
                 for n in nodes_order]
        if len(nodes_order) == 2:
            flow = "r"
            if len(prim) == 1 and prim[0] == nodes_order[1]:
                flow = "l"
            if st["blind"]:
                wstate = "none"
            elif split or not st["replication"]["streaming"]:
                wstate = "bad"
            else:
                wstate = "ok"
            lagbits = []
            for n in nodes_order:
                h = per[n].get("health") or {}
                if per[n].get("pg") == "standby" and h.get("wal_lag", -1) >= 0:
                    lagbits.append("未回放 %s" % human_bytes(h["wal_lag"]))
                if per[n].get("pg") == "primary" and h.get("sender_lag", -1) >= 0:
                    lagbits.append("最落后 %s" % human_bytes(h["sender_lag"]))
            wl = {"ok": "WAL 复制：流动中",
                  "bad": "WAL 复制：★ 没在真实复制",
                  "none": "WAL 复制：观测不可信"}[wstate]
            if lagbits:
                wl += "（%s，均自报）" % "，".join(lagbits)
            dash = (cards[0] + wire(flow, wstate, esc(wl)) + cards[1])
        else:
            dash = "".join(cards)

        dash = ('<div class="dash">%s</div>'
                '<p class="meta">灯：<b>绿＝主库　蓝＝备库　红＝状态未知</b>'
                '（没上报／过期／两台都自报主库，都算"看不清"）；'
                '箭头＝复制流向，<b>停住或变红＝没在真实复制</b>。<br>'
                '数据＝各节点每 30 秒一轮的<b>自报</b>（待验证，未采信）'
                '＋本节点自己观测；结论以上面的综合状态与下面的判定表为准。</p>'
                % dash)

        advice = standby_advice(st, esc)

        # ★ 看板新增的样式与那一行刷新脚本。**单独作为值插入**，
        #   不参与外层 .format 的括号转义 —— 免得满屏 {{ }} 里再错一个。
        dash_css = """<style>
.dash{display:flex;align-items:stretch;gap:16px;margin:18px 0 6px}
.card{flex:0 0 260px;border:1px solid #e0e0e0;border-top:5px solid #9e9e9e;
      border-radius:8px;padding:14px 16px;background:#fff}
.card.green{border-top-color:#2e7d32} .card.blue{border-top-color:#1565c0}
.card.red{border-top-color:#c62828}
.lamp{text-align:center;margin:2px 0 8px}
.lamp i{display:inline-block;width:22px;height:22px;border-radius:50%;
        background:#c62828}
.lamp.green i{background:#2e7d32;animation:bg 2.4s ease-in-out infinite}
.lamp.blue i{background:#1565c0;animation:bb 2.4s ease-in-out infinite}
@keyframes bg{0%,100%{box-shadow:0 0 3px 1px rgba(46,125,50,.35);opacity:.55}
              50%{box-shadow:0 0 16px 6px rgba(46,125,50,.75);opacity:1}}
@keyframes bb{0%,100%{box-shadow:0 0 3px 1px rgba(21,101,192,.35);opacity:.55}
              50%{box-shadow:0 0 16px 6px rgba(21,101,192,.75);opacity:1}}
.ip{font-size:20px;font-weight:700;text-align:center}
.role{text-align:center;font-weight:600;margin-bottom:6px}
.role.green{color:#2e7d32} .role.blue{color:#1565c0} .role.red{color:#c62828}
.badge{text-align:center;background:#fff3e0;color:#e65100;border-radius:4px;
       padding:2px 6px;font-size:12px;font-weight:600;margin:2px 0 6px}
.kv2{font-size:13px;color:#444;margin:3px 0}
.svcs{margin:6px 0 2px}
.svc{margin-right:10px;font-size:13px;color:#555}
.sdot{display:inline-block;width:9px;height:9px;border-radius:50%;
      margin-left:4px;background:currentColor}
.wirewrap{flex:1;display:flex;flex-direction:column;justify-content:center;
          min-width:140px}
.wire{height:36px;overflow:hidden;position:relative}
.track{position:absolute;left:0;top:0;white-space:nowrap}
.track span{display:inline-block;width:30px;text-align:center;font-size:22px;
            line-height:36px;color:#9e9e9e}
.wire.ok .track span{color:#2e7d32}
.wire.bad .track span{color:#c62828}
.wire.ok.r .track{animation:fr 1s linear infinite}
.wire.ok.l .track{animation:fl 1s linear infinite}
@keyframes fr{from{transform:translateX(-30px)}to{transform:translateX(0)}}
@keyframes fl{from{transform:translateX(0)}to{transform:translateX(-30px)}}
.wirelab{text-align:center;font-size:12px;color:#666;margin-top:4px}
.vip{font-size:17px;font-weight:600;padding:8px 12px;border-radius:6px;
     background:#e8f5e9;color:#1b5e20}
.vip.vbad{background:#ffebee;color:#b71c1c}
details.advice{margin:12px 0;border:1px solid #ffcc80;background:#fff8e1;
               border-radius:6px;padding:4px 12px}
details.advice summary{cursor:pointer;font-weight:700;color:#e65100;padding:6px 0}
.why{color:#555;font-size:13px}
ol.steps li{margin:6px 0;line-height:1.7}
ol.steps code{font-size:12px}
</style>"""

        # ★ 自动刷新的那**一行** JS：展开着建议操作时**不刷**，
        #   免得 15 秒一到把人正在看的步骤收起来。没有它也能用（手动 F5）。
        dash_js = """<script>
setInterval(function(){
  if (!document.querySelector('details[open]')) location.reload();
}, 15000);
</script>"""

        html = """<!doctype html><html lang="zh-CN"><meta charset="utf-8">
<title>Zabbix HA 仲裁节点</title>
<style>
body{{font-family:system-ui,"Microsoft YaHei",sans-serif;margin:24px;color:#222;max-width:1100px}}
h1{{font-size:20px;margin:0 0 4px}}
.big{{font-size:30px;font-weight:700;color:{color}}}
table{{border-collapse:collapse;margin-top:12px;width:100%}}
th,td{{border-bottom:1px solid #e0e0e0;padding:6px 8px;text-align:left;font-size:14px}}
th{{background:#fafafa;font-size:13px;color:#666}}
tr.ad td{{color:#666;font-size:13px;padding:2px 8px}}
tr.hlth td{{color:#555;font-size:13px;padding:2px 8px;background:#fbfbfb}}
.tag{{background:#e8eaf6;color:#3949ab;border-radius:3px;padding:1px 5px;font-size:12px}}
.st-ok{{color:#2e7d32}} .st-warn{{color:#ef6c00}}
.st-bad{{color:#c62828;font-weight:600}} .st-na{{color:#9e9e9e}}
.rc0{{color:#2e7d32}} .rc1{{color:#c62828}} .rc2{{color:#ef6c00}} .rc3{{color:#8d6e63}}
.warn{{background:#fff8e1;border-left:4px solid #ef6c00;padding:8px 12px}}
.meta{{color:#666;font-size:13px;margin-top:16px;line-height:1.7}}
code{{background:#f4f4f4;padding:2px 5px;border-radius:3px}}
</style>
{dash_css}
{dash_js}
<h1>Zabbix 高可用 —— 仲裁节点</h1>
<p class="big">{composite}</p>
<p>{reason}</p>
<p class="vip {vipcls}">{viptxt}</p>
{mnt}
{dash}
{advice}
<table>
<tr><th>节点</th><th>判定</th><th>PG 自报</th><th>角色声明</th><th>持 VIP</th><th>证据年龄</th></tr>
{rows}
</table>
<p class="meta">
观测时刻 {observed}（{age} 秒前）　|　证据上限 {ttl} 秒　|
自检闸 <b>{sc}</b>　|　备库真实复制 <b>{repl}</b><br>
VIP {vip}　持有者 MAC {holder}<br>
适配器退出码：<span class="rc0">0 证据成立</span>／<span class="rc1">1 证据不成立（拦住）</span>／
<span class="rc2">2 不可用（我们瞎了）</span>／<span class="rc3">3 无结论（看了，但看不出，降级为否决型）</span><br>
★ 标着<b>自报</b>的那一行是<b>节点自己说的</b>（未采信，不进判定）；其余各列是仲裁节点自己观测到的。
分区时"自报"会停在最后一刻的值，所以它过期即整条作废，不做半新半旧的显示。<br>
★ <b>本节点永久只读</b>：它只回答"能不能"，从不执行任何启动、停止或电源操作。<br>
★ 维护窗口（★ 只能在本机执行 —— 本页面刻意不加会改状态的端点）。
<b>窗口是全局的</b>，没有"对象节点"参数：开之前先确认<b>两台</b>都可以不被自动接管；
哪一台要动手只能写进 <code>--reason</code>，否则事后没人说得清：
<code>sudo /opt/zbx-arbiter/arbiter-window.py open --minutes 30 --reason '221 内核升级'</code>
<code>… close</code>　<code>… show</code>
</p>
</html>""".format(
            color=color, composite=esc(c), reason=esc(st["composite_reason"]),
            vipcls=vip_cls, viptxt=vip_txt, dash_css=dash_css, dash_js=dash_js,
            dash=dash, advice=advice,
            mnt=mnt_html, rows="\n".join(rows),
            observed=esc(st["observed_at"] or "（尚未观测）"),
            age=(st["observed_age_sec"] if st["observed_age_sec"] is not None else "?"),
            ttl=st["verdict_ttl"],
            sc=("通过" if st["selfcheck"]["ok"] else "★ 未通过"),
            repl=("是" if st["replication"]["streaming"] else "否"),
            vip=esc(st["vip"]["address"]), holder=esc(st["vip"]["holder_mac"]))
        return self._send(200, html, "text/html; charset=utf-8")


# ============================================================
# 入口
# ============================================================

def serve():
    conf = Conf()
    store = Store(conf)
    Handler.conf = conf
    Handler.store = store

    addr = (conf.get("LISTEN_ADDR") or "0.0.0.0").strip()
    port = conf.getint("LISTEN_PORT", 8080)

    if not conf.token:
        log("★★ ARBITER_TOKEN 为空 —— 节点侧会拒绝所有判定。请先填好 arbiter.conf。")
    if not conf.allow_from:
        log("★★ ARBITER_ALLOW_FROM 为空 —— 所有请求都会被拒绝。"
            "至少要把 VIP 与两台节点 IP 填进去（漏了 VIP 会让 Zabbix 采不到数据）。")
    if not conf.nodes or not all(conf.nodes):
        log("★★ NODE_A_IP / NODE_B_IP 没填全 —— 无法判定。")

    log("仲裁节点启动：监听 %s:%d，适配器目录 %s，状态目录 %s"
        % (addr, port, conf.adapter_dir, conf.state_dir))
    srv = ThreadingHTTPServer((addr, port), Handler)
    srv.daemon_threads = True
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        log("收到中断，退出。")


if __name__ == "__main__":
    serve()
