#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ============================================================
# 20-oob-esxi.py —— 对端电源状态（ESXi 直连 / vCenter）【判据型】
#
#   类别：★ 判据型（必须同时加进 arbiter.conf 的 JUDGE_LEVEL_ADAPTERS 白名单）
#   强度：A —— 带外证据，不受生产网分区影响
#   依赖：pyVmomi（pip3 install pyvmomi 或 apt install python3-pyvmomi）
#
# 输入：$1 = 待判定的**对端** IP
# 输出：stdout 第一行 = 理由（进 verdict.reason）；其余行 = 原始观测值
# 退出：0 证据成立（poweredOff / suspended，确证不在服务）
#       1 证据不成立（★ 本适配器**永远不会**返回 1，原因见下）
#       2 不可用（连不上 / 没配 / connectionState 不可信 / 认不出）
#       3 无结论（poweredOn）
#
# ------------------------------------------------------------
# ★★ 两件必须做对的事
#
# 一、`poweredOn` 返回 3，不返回 1。
#     "电源是开的"不等于"它在服务" —— 一台健康的备库也是开着的。
#     返回 1 会一票否决，于是 §6.1 场景 12（两台同时重启、各归各位）里，
#     声明为主库的那台永远等不到许可。详见需求文档 §2.3。
#
# 二、**必须先判 `connectionState`，再看 `powerState`。**
#     这是虚拟化观测里最容易踩的坑：
#
#       ESXi 主机掉线（connectionState = disconnected / notResponding）时，
#       vCenter 返回的 `powerState` 是**最后一次已知的缓存值**，
#       不是此刻的事实。一台已经关了的虚机，缓存里可能还写着 poweredOn；
#       反过来一台正在跑的，缓存里可能写着 poweredOff。
#
#     所以顺序是：**先确认"这个电源状态是不是可信的"，再去读它**。
#     连接状态不对 → 这一路观测就是瞎的 → 2（不可用），
#     绝不能拿一个缓存值去当"确证不在服务"（那会一票放行）。
#
# ------------------------------------------------------------
# 配置：/etc/zbx-arbiter/adapters.d/20-oob-esxi.conf（600）
#
#   ★ 键名里带节点 IP，没有 A/B 下标 —— 下标要靠人工对齐 NODE_A_IP，
#     填错一次就是"A 的问到 B 的虚机"，而且不会有任何报错。
#
#   【走 vCenter（推荐：一次连接看全部）】
#     VCENTER_HOST=10.10.0.5
#     VCENTER_USER='administrator@vsphere.local'
#     VCENTER_PWD='...'
#     VCENTER_PORT=443                 # 可选
#     VCENTER_CA_BUNDLE=/etc/ssl/certs/xxx.pem   # 可选；不填 = 不校验证书
#
#   【或直连 ESXi（每台节点一台宿主机）】
#     ESXI_HOST_192.168.2.221=10.10.0.31
#     ESXI_HOST_192.168.2.222=10.10.0.32
#     ESXI_USER=root
#     ESXI_PWD='...'
#
#   【虚机怎么认】
#     默认按 MAC 自动匹配（ARBITER_PEER_MAC，由仲裁节点从 ARP 邻居表学到）。
#     名字不规律、或一台虚机多网卡时，显式指定更稳：
#     ESXI_VM_192.168.2.221=zbx-pg-221
#     ESXI_VM_192.168.2.222=zbx-pg-222
#
#   【可选】
#     ESXI_VERIFY=no                   # yes 时启用证书校验（需 CA_BUNDLE）
# ============================================================

import os
import ssl
import sys

CONF_DIR = os.environ.get("ARBITER_ADAPTER_CONF_DIR",
                          "/etc/zbx-arbiter/adapters.d")
CONF = os.path.join(CONF_DIR, os.path.basename(__file__).rsplit(".", 1)[0] + ".conf")


def cfg_get(conf, key, default=""):
    """与 §8.3 同一条纪律：整行注释，值可带单引号。"""
    try:
        with open(conf, encoding="utf-8-sig") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                k, sep, v = line.partition("=")
                if not sep or k.strip() != key:
                    continue
                v = v.strip()
                if len(v) >= 2 and v[0] == v[-1] and v[0] in ("'", '"'):
                    v = v[1:-1]
                return v
    except OSError:
        pass
    return default


def say(reason, *raw):
    """第一行 = 理由（进 verdict.reason），其余 = 原始观测值。"""
    sys.stdout.write(reason + "\n")
    for line in raw:
        sys.stdout.write("%s\n" % line)


def main():
    if len(sys.argv) < 2 or not sys.argv[1].strip():
        say("没有传入待判定的对端 IP（契约：$1 = 对端 IP）")
        return 2
    peer = sys.argv[1].strip()
    peer_mac = (os.environ.get("ARBITER_PEER_MAC") or "").strip().lower()

    if not os.path.isfile(CONF):
        say("没有 %s —— 这台节点未配置虚拟化平台观测" % CONF)
        return 2

    try:
        from pyVim.connect import SmartConnect, Disconnect
        from pyVmomi import vim
    except ImportError as e:
        say("没有 pyvmomi，虚拟化平台观测不可用：%s" % e)
        return 2

    # ---- 连谁 ----
    vc_host = cfg_get(CONF, "VCENTER_HOST")
    if vc_host:
        host, port = vc_host, int(cfg_get(CONF, "VCENTER_PORT", "443") or 443)
        user = cfg_get(CONF, "VCENTER_USER")
        pwd = cfg_get(CONF, "VCENTER_PWD")
        ca = cfg_get(CONF, "VCENTER_CA_BUNDLE")
        where = "vCenter %s" % vc_host
    else:
        host = cfg_get(CONF, "ESXI_HOST_%s" % peer)
        port = int(cfg_get(CONF, "ESXI_PORT", "443") or 443)
        user = cfg_get(CONF, "ESXI_USER")
        pwd = cfg_get(CONF, "ESXI_PWD")
        ca = cfg_get(CONF, "ESXI_CA_BUNDLE")
        where = "ESXi %s" % (host or "（未配置）")
        if not host:
            say("%s 里既没有 VCENTER_HOST，也没有 ESXI_HOST_%s —— "
                "对端 %s 未配置虚拟化平台观测" % (CONF, peer, peer))
            return 2

    if not user:
        say("%s 里没有账号配置 —— 配置不完整" % CONF)
        return 2

    verify = (cfg_get(CONF, "ESXI_VERIFY", "").lower() in ("yes", "1", "true")
              or cfg_get(CONF, "VCENTER_VERIFY", "").lower() in ("yes", "1", "true"))
    if verify and ca:
        ctx = ssl.create_default_context(cafile=ca)
        tls_note = "证书校验：开（%s）" % ca
    else:
        ctx = ssl._create_unverified_context()
        tls_note = ("证书校验：★ 关 —— 这条链路上有人能冒充虚拟化平台，"
                    "需要在 %s 里配 *_CA_BUNDLE" % CONF)

    si = None
    try:
        si = SmartConnect(host=host, user=user, pwd=pwd, port=port,
                          sslContext=ctx)
        content = si.RetrieveContent()
        container = content.viewManager.CreateContainerView(
            content.rootFolder, [vim.VirtualMachine], True)
        vms = list(container.view)
        container.Destroy()

        want_name = cfg_get(CONF, "ESXI_VM_%s" % peer)
        vm = _pick_vm(vms, vim, want_name, peer_mac)
        if vm is None:
            # ★ 找不到 = 台账对不上，不能猜。猜"它不在了"就是拿清单陈旧当证据。
            say("在 %s 上找不到对端 %s 的虚机（%s）—— 清单与实际不一致，"
                "这一路得不出结论"
                % (where, peer,
                   ("按名字 %s" % want_name) if want_name
                   else ("按 MAC %s" % (peer_mac or "（本机还没学到对端的 MAC）"))),
                "共 %d 台虚机，tls=%s" % (len(vms), tls_note))
            return 2

        raw = _describe(vm)
        power = _power_state(vm)
        host_conn = _host_conn_state(vm)
        vm_conn = _conn_of(getattr(vm, "runtime", None))

        # ---- 一、先判可信度：电源状态是不是此刻的事实 ----
        # ★ ESXi 主机掉线时，vCenter 给的 powerState 是缓存值。
        #   缓存值不能当"确证不在服务" —— 那会一票放行。
        #
        # ★★ 判据必须**正面成立**：`!= connected` 一律挡回去，**包括读不到**。
        #    这里不接受 None 放行 —— "读不到连接状态"就是"不知道这个电源值新不新"，
        #    与"确认它可信"是两回事。同 §2.3：判据不可用 ≠ 判据通过。
        if host_conn != "connected":
            say("ESXi 主机连接状态不是 connected（读到的是 %s）—— "
                "电源状态是缓存值，不可信，这一路得不出结论"
                % (host_conn if host_conn else "读不到"),
                "vm=%s  host.connectionState=%s  vm.connectionState=%s"
                % (raw, host_conn, vm_conn),
                "powerState=%s（★ 缓存值，不作为依据）" % power,
                "where=%s  tls=%s" % (where, tls_note))
            return 2
        if vm_conn != "connected":
            say("虚机自身连接状态不是 connected（读到的是 %s）—— 观测不可信，"
                "这一路得不出结论" % (vm_conn if vm_conn else "读不到"),
                "vm=%s  host.connectionState=%s  vm.connectionState=%s"
                % (raw, host_conn, vm_conn),
                "powerState=%s（★ 缓存值，不作为依据）" % power,
                "where=%s  tls=%s" % (where, tls_note))
            return 2
        if power is None:
            say("虚机 %s 没有可识别的 powerState —— 这一路得不出结论" % raw,
                "vm=%s  host.connectionState=%s  vm.connectionState=%s"
                % (raw, host_conn, vm_conn),
                "where=%s  tls=%s" % (where, tls_note))
            return 2

        # ---- 二、可信了，再读它 ----
        if power == "poweredOff":
            say("虚拟化平台确认对端 %s 电源关闭（%s）" % (peer, where),
                "vm=%s  powerState=poweredOff  host.connectionState=%s"
                % (raw, host_conn),
                "where=%s  tls=%s" % (where, tls_note))
            return 0

        if power == "suspended":
            # 挂起的虚机不占 CPU、不接流量，确实不在服务。
            # ★ 但这是个会被人追问的判定，所以理由里必须写明是挂起而不是关机。
            say("虚拟化平台确认对端 %s 处于**挂起**状态（%s）—— "
                "挂起的虚机不提供服务" % (peer, where),
                "vm=%s  powerState=suspended  host.connectionState=%s"
                % (raw, host_conn),
                "where=%s  tls=%s" % (where, tls_note))
            return 0

        if power == "poweredOn":
            say("对端 %s 电源开着（%s）—— 开机不等于在服务，本路得不出结论"
                % (peer, where),
                "vm=%s  powerState=poweredOn  host.connectionState=%s"
                % (raw, host_conn),
                "where=%s  tls=%s" % (where, tls_note))
            return 3

        say("对端 %s 的 powerState 是 %s，不在已知取值里 —— "
            "这一路得不出结论" % (peer, power),
            "vm=%s  host.connectionState=%s" % (raw, host_conn),
            "where=%s  tls=%s" % (where, tls_note))
        return 2

    except Exception as e:  # noqa: BLE001 —— 任何异常都只能是"不可用"
        # ★ 兜底必须是 2，不能是 0，也不能是 3。
        #   连不上虚拟化平台 = 这一路观测是瞎的，调用方会把它记进退化。
        say("连不上虚拟化平台（%s）：%s: %s" % (where, type(e).__name__, e),
            "where=%s  tls=%s" % (where, tls_note))
        return 2
    finally:
        try:
            if si is not None:
                Disconnect(si)
        except Exception:
            pass


# ------------------------------------------------------------
# pyVmomi 取值：全部走 getattr 链，缺一层就返回 None，
# 绝不抛异常 —— 观测代码抛异常会把"读不到"和"看错了"混在一起。
# ------------------------------------------------------------

def _pick_vm(vms, vim, want_name, want_mac):
    if want_name:
        for vm in vms:
            try:
                if vm.name == want_name:
                    return vm
            except Exception:
                continue
        return None
    if not want_mac:
        return None
    for vm in vms:
        try:
            hw = vm.config.hardware.device
        except Exception:
            continue
        for dev in hw or []:
            try:
                if isinstance(dev, vim.vm.device.VirtualEthernetCard):
                    if (dev.macAddress or "").lower() == want_mac:
                        return vm
            except Exception:
                continue
    return None


def _conn_of(runtime):
    if runtime is None:
        return None
    try:
        return runtime.connectionState
    except Exception:
        return None


def _power_state(vm):
    try:
        return vm.runtime.powerState
    except Exception:
        return None


def _host_conn_state(vm):
    """★ 这个值决定 powerState 可不可信。取不到就返回 None（调用方按"不可信"处理）。"""
    try:
        rt = vm.runtime.host
        if rt is None:
            return None
        return rt.runtime.connectionState
    except Exception:
        return None


def _describe(vm):
    try:
        name = vm.name
    except Exception:
        name = "?"
    try:
        host = vm.runtime.host.name
    except Exception:
        host = "?"
    return "%s@%s" % (name, host)


if __name__ == "__main__":
    sys.exit(main())
