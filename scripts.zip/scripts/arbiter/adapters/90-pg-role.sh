#!/bin/bash
# ============================================================
# 90-pg-role.sh —— 读对端的 PG 角色【否决型】
#
#   类别：★ 否决型（**默认类别，不要把它加进 JUDGE_LEVEL_ADAPTERS**）
#   强度：C —— 弱证据，只作旁证
#   依赖：psql
#
# 输入：$1 = 待判定的**对端** IP
# 输出：stdout 第一行 = 理由（进 verdict.reason）；其余行 = 原始观测值
# 退出：0 证据成立（对端自报是备库 = 不在服务）
#       1 证据不成立（对端自报**是主库** = 它在服务）—— 一票否决
#       2 不可用（认证失败 / 参数错 / 没有 psql）
#       3 无结论（连不上 / 超时 / 输出认不出来）
#
# ------------------------------------------------------------
# ★★ 这个适配器是**单向**的，两个方向必须分开看
#
#   `f`（不是备库 ⇒ 是主库）：**确证对端在服务** → 一票否决。
#       这是它唯一有价值的能力，也是整个方案里最便宜的一道保险：
#       只要还能读到对端，就绝不会出现双主。
#
#   `t`（是备库）：不否决。备库不接写流量，但**它不是"不在服务"的证明** ——
#       它只是"不在**主库**这个角色上"。所以这里返回 0 的含义严格来说只是
#       "我没看见对端在服务"，而不是"我确证对端不在服务"。
#       这正是它被判为**否决型**的原因：它的 0 不许当一票通过。
#
# ------------------------------------------------------------
# ★★ 连不上 ≠ 对端不在服务（本方案最核心的一条警告）
#
#   直觉上很容易写成"5432 连不上 → 许可"。**那是错的**，会打死两个主功能：
#     主库冷启动被误拒、§6.1 场景 12（两台同时重启、各归各位）失效。
#   备库活着但没在服务是**常态**；而且"连不上"和"被防火墙挡住"
#   在我们这一侧看起来是一样的。
#
#   所以：
#     连接被拒（RST）  → 3  端口上确实没人应答，但 PG 可能换了端口或被
#                            bind 到了别的地址 —— 不构成"对端不在服务"的证明
#     连接超时         → 3  对端可能只是和我们断了，见 R1
#     认证失败         → 2  ★ 这是**我们自己**的配置坏了，必须报出来
#
#   ★ 2 与 3 的差别是有意义的：2 会让综合状态进入 DEGRADED_EVIDENCE，
#     3 不会。凭据过期是需要人去修的事，而"对端关机了所以连不上"不是。
#
# ------------------------------------------------------------
# 配置：/etc/zbx-arbiter/adapters.d/90-pg-role.conf（600）
#
#   ★ 用**只读的 probe 角色**，不要用 postgres 超级用户：
#     这个账号只需要能执行 `select pg_is_in_recovery()`。
#
#     PG_ROLE_PORT=5432
#     PG_ROLE_USER=probe
#     PG_ROLE_PWD='...'
#     PG_ROLE_DB=postgres
#     PG_ROLE_TIMEOUT=5        # 可选，连接超时（秒）
#
#   ★ 连的地址就是 $1（对端 IP），没有 A/B 下标要人工对齐。
# ============================================================
set -u

PEER=${1:-}
if [ -z "$PEER" ]; then
    echo "没有传入待判定的对端 IP（契约：\$1 = 对端 IP）"
    exit 2
fi

SELF=$(basename "$0")
base=${SELF%.*}
CONF_DIR=${ARBITER_ADAPTER_CONF_DIR:-/etc/zbx-arbiter/adapters.d}
CONF="$CONF_DIR/$base.conf"

# ★ 第一句 sed 是剥 BOM：配置文件被记事本编辑过、或从 Windows 共享盘拷过来时，
#   文件头会带 BOM，它会粘在**第一个键名**上让那个键静默消失（§8.3）。
cfg_get() {
    [ -r "$CONF" ] || return 1
    sed -e '1s/^\xEF\xBB\xBF//' "$CONF" \
        | sed -n "s/^[[:space:]]*$1=//p" | head -1 \
        | sed -e "s/^'\(.*\)'$/\1/" -e "s/^\"\(.*\)\"$/\1/"
}

if [ ! -r "$CONF" ]; then
    echo "没有 $CONF —— 未配置 PG 角色观测"
    exit 2
fi

PORT=$(cfg_get PG_ROLE_PORT); [ -n "$PORT" ] || PORT=5432
USER_=$(cfg_get PG_ROLE_USER)
PWD_=$(cfg_get PG_ROLE_PWD)
DB=$(cfg_get PG_ROLE_DB); [ -n "$DB" ] || DB=postgres
TMO=$(cfg_get PG_ROLE_TIMEOUT); [ -n "$TMO" ] || TMO=5

if [ -z "$USER_" ]; then
    echo "$CONF 里没有 PG_ROLE_USER —— 配置不完整"
    exit 2
fi
if ! command -v psql >/dev/null 2>&1; then
    echo "找不到 psql（apt install postgresql-client-17）"
    exit 2
fi

# ★ PGPASSFILE=/dev/null：不让某个用户的 ~/.pgpass 悄悄顶掉这里的凭据。
#   否则"凭据过期"会在这个适配器上表现成别的样子，排查时白跑一圈。
# ★ -w：绝不弹密码提示（stdin 不是终端，但明确写出来）。
OUT=$(
    PGPASSWORD="$PWD_" \
    PGPASSFILE=/dev/null \
    PGCONNECT_TIMEOUT="$TMO" \
    PGSSLMODE="${PG_ROLE_SSLMODE:-prefer}" \
    psql -w -h "$PEER" -p "$PORT" -U "$USER_" -d "$DB" \
         -tAc "select pg_is_in_recovery()" 2>&1
)
RC=$?

# 把输出归一：只留下 t / f / 其他
VAL=$(printf '%s\n' "$OUT" | tr -d '[:space:]')

case "$VAL" in
    f)
        echo "对端 $PEER 自报**是主库**（pg_is_in_recovery()=f）—— 它正在服务，不能放行"
        echo "psql rc=$RC  host=$PEER port=$PORT user=$USER_ db=$DB"
        printf '%s\n' "$OUT" | head -3
        exit 1
        ;;
    t)
        echo "对端 $PEER 自报是备库（pg_is_in_recovery()=t）—— 不是主库，不否决"
        echo "psql rc=$RC  host=$PEER port=$PORT user=$USER_ db=$DB"
        printf '%s\n' "$OUT" | head -3
        exit 0
        ;;
esac

# ---- 认不出 t/f：都是"得不出结论"，除非是我们自己的凭据坏了 ----
case "$OUT" in
    *"no password supplied"*|*"authentication failed"*|*"password authentication"*|\
    *"role \""*"does not exist"*|*"database \""*"does not exist"*|\
    *"no pg_hba.conf entry"*)
        # ★ 必须报 2：这是**我们自己**的配置坏了，与对端在不在服务无关。
        #   混成 3 就等于把"监控在退化"藏了起来，凭据过期会一直没人发现。
        echo "PG 角色观测不可用：凭据/参数被拒（对端 $PEER:$PORT，用户 $USER_）"
        echo "psql rc=$RC  user=$USER_  db=$DB  —— 这是本地配置问题，不是对端的问题"
        printf '%s\n' "$OUT" | head -5
        exit 2
        ;;
    *"Connection refused"*|*"could not connect to server"*|*"connection refused"*)
        echo "对端 $PEER:$PORT 上没有 PG 在监听 —— 但这不构成'对端不在服务'的证明" \
             "（端口可能被改过，或 PG 被 bind 到了别的地址），本路得不出结论"
        echo "psql rc=$RC  host=$PEER port=$PORT"
        printf '%s\n' "$OUT" | head -5
        exit 3
        ;;
    *"timeout"*|*"timed out"*|*"Timeout"*)
        echo "连对端 $PEER:$PORT 超时 —— 对端不可达不等于对端不在服务（见 R1），" \
             "本路得不出结论"
        echo "psql rc=$RC  host=$PEER port=$PORT timeout=${TMO}s"
        printf '%s\n' "$OUT" | head -5
        exit 3
        ;;
esac

echo "PG 角色观测的输出认不出来（对端 $PEER:$PORT，rc=$RC）—— 本路得不出结论"
printf '%s\n' "$OUT" | head -8
exit 3
