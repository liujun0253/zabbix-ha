#!/bin/bash
# ============================================================
# 20-oob-ipmi.sh —— 对端电源状态【判据型】
#
#   类别：★ 判据型（必须同时加进 arbiter.conf 的 JUDGE_LEVEL_ADAPTERS 白名单）
#   强度：A —— 带外证据，不受生产网分区影响
#   依赖：ipmitool
#
# 输入：$1 = 待判定的**对端** IP
# 输出：stdout 第一行 = 理由（进 verdict.reason）；其余行 = 原始观测值
# 退出：0 证据成立（poweredOff，确证不在服务）
#       1 证据不成立（★ 本适配器**永远不会**返回 1，原因见下）
#       2 不可用（BMC 连不上 / 没配 / 认不出输出）
#       3 无结论（poweredOn）
#
# ------------------------------------------------------------
# ★★ 为什么 `poweredOn` 必须返回 3，而不是 1
#
#   "电源是开的"**不等于**"它在服务" —— 一台健康的备库也是开着的。
#   如果这里对 poweredOn 返回 1（一票否决），那么：
#
#     §6.1 场景 12（**两台同时重启、各归各位**）里，
#     声明为主库的那台**永远等不到启动许可** —— 因为它的对端是备库，
#     而备库当然也开着机。整个冷启动路径失效。
#
#   返回 3 的效果是把自己降级成否决型：既不放行也不否决，
#   而且**不计入退化**（这个适配器在正常工作，只是这一路观测回答不了这个问题）。
#   详见需求文档 §2.3。
#
# ★★ 关于"BMC 连不上"为什么是 2 而不是 0
#   带外电源是**常年带电**的：被观测的机器关机了，BMC 也还在线。
#   所以"BMC 连不上"就是**观测链路坏了**，与对端是否在服务无关。
#   把它算成 0 就是拿"我们瞎了"当"对端不在服务" —— 本方案最危险的那类错误。
#
# ------------------------------------------------------------
# 配置：/etc/zbx-arbiter/adapters.d/20-oob-ipmi.conf（600）
#
#   ★ 键名里带节点 IP，**没有 A/B 下标** —— 下标要靠人工对齐 NODE_A_IP，
#     填错一次就是"A 的问到 B 的 BMC"，而且不会有任何报错。
#     这里用 $1（对端 IP）直接查表，填错立刻表现为"这台没配 BMC"。
#
#     IPMI_HOST_192.168.2.221=10.10.0.11
#     IPMI_HOST_192.168.2.222=10.10.0.12
#     IPMI_USER=admin
#     IPMI_PWD='...'
#     IPMI_INTERFACE=lanplus          # 可选，默认 lanplus
#     IPMI_EXTRA=''                   # 可选，附加参数
#     IPMI_BIN=/usr/bin/ipmitool      # 可选
# ============================================================
set -u

PEER=${1:-}
if [ -z "$PEER" ]; then
    echo "没有传入待判定的对端 IP（契约：\$1 = 对端 IP）"
    exit 2
fi

SELF=$(basename "$0")
base=${SELF%.*}
CONF_DIR=${ARBITER_ADAPTER_CONF_DIR:-/etc/zbx-arbiter/adapters.d}
CONF="$CONF_DIR/$base.conf"

# 与 §8.3 同一条纪律：整行注释，值可带单引号。
# ★ 第一句 sed 是剥 BOM：配置文件被记事本编辑过、或从 Windows 共享盘拷过来时，
#   文件头会带 BOM，它会粘在**第一个键名**上让那个键静默消失（§8.3）。
cfg_get() {
    [ -r "$CONF" ] || return 1
    sed -e '1s/^\xEF\xBB\xBF//' "$CONF" \
        | sed -n "s/^[[:space:]]*$1=//p" | head -1 \
        | sed -e "s/^'\(.*\)'$/\1/" -e "s/^\"\(.*\)\"$/\1/"
}

if [ ! -r "$CONF" ]; then
    echo "没有 $CONF —— 这台节点未配置带外电源观测"
    exit 2
fi

BMC=$(cfg_get "IPMI_HOST_$PEER")
if [ -z "$BMC" ]; then
    echo "$CONF 里没有 IPMI_HOST_$PEER —— 对端 $PEER 未配置 BMC 地址"
    exit 2
fi

USER_=$(cfg_get IPMI_USER)
PWD_=$(cfg_get IPMI_PWD)
IFACE=$(cfg_get IPMI_INTERFACE)
EXTRA=$(cfg_get IPMI_EXTRA)
IPMITOOL=$(cfg_get IPMI_BIN)
[ -n "$IPMITOOL" ] || IPMITOOL=/usr/bin/ipmitool
[ -n "$IFACE" ] || IFACE=lanplus

if [ ! -x "$IPMITOOL" ]; then
    IPMITOOL=$(command -v ipmitool 2>/dev/null || true)
fi
if [ -z "$IPMITOOL" ] || [ ! -x "$IPMITOOL" ]; then
    echo "找不到 ipmitool（apt install ipmitool）"
    exit 2
fi
if [ -z "$USER_" ]; then
    echo "$CONF 里没有 IPMI_USER —— 配置不完整"
    exit 2
fi

# ★ 密码走环境变量（-E），不走命令行。
#   `-P <密码>` 会把密码暴露在 ps 输出里 —— 这台机器上任何用户都看得到。
OUT=$(
    IPMI_PASSWORD="$PWD_" "$IPMITOOL" -I "$IFACE" -H "$BMC" -U "$USER_" -E \
        $EXTRA chassis power status 2>&1
)
RC=$?

# ---- 先看输出，再看退出码 ----
# ★ ipmitool 在部分版本里即便打印了错误也返回 0，所以退出码只能当参考，
#   真正的判据是输出里的那行 "Chassis Power is on|off"。
case "$OUT" in
    *"Chassis Power is off"*)
        echo "带外确认对端 $PEER 电源关闭（BMC $BMC：Chassis Power is off）"
        echo "ipmitool rc=$RC  interface=$IFACE"
        printf '%s\n' "$OUT" | head -3
        exit 0
        ;;
    *"Chassis Power is on"*)
        echo "对端 $PEER 电源开着（BMC $BMC）—— 开机不等于在服务，本路得不出结论"
        echo "ipmitool rc=$RC  interface=$IFACE"
        printf '%s\n' "$OUT" | head -3
        exit 3
        ;;
esac

echo "带外电源观测不可用：BMC $BMC 没有给出可识别的电源状态（rc=$RC）"
echo "ipmitool rc=$RC  interface=$IFACE  bmc=$BMC"
printf '%s\n' "$OUT" | head -8
exit 2
