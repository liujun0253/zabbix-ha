#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ============================================================
# 30-snmp-switch.py —— 接入交换机的 MAC 地址表 / 端口状态【判据型】
#
#   类别：★ 判据型（必须同时加进 arbiter.conf 的 JUDGE_LEVEL_ADAPTERS 白名单）
#   强度：高 —— 交换机自己的转发表不受分区影响
#   依赖：无（标准库手写 SNMP v2c，不装 net-snmp）
#
# 输入：$1 = 待判定的**对端** IP
# 输出：stdout 第一行 = 理由（进 verdict.reason）；其余行 = 原始观测值
# 退出：0 证据成立（对端的 MAC **不在**交换机地址表里 = 它已不在这个网上）
#       1 证据不成立（★ 本适配器**永远不会**返回 1，原因见下）
#       2 不可用（交换机连不上 / 没配 / 地址表读不全）
#       3 无结论（MAC 仍在表里 / 端口是 up / 表是空的）
#
# ------------------------------------------------------------
# ★★ 为什么"MAC 还在表里"必须返回 3，而不是 1
#
#   "MAC 在地址表里"证明的是**对端还连在网上**，不是**对端在服务**。
#   一台健康的备库当然也连着网 —— 它的 MAC 也当然在表里。
#
#   如果这里对"MAC 在表里"返回 1（一票否决），那么 §6.1 场景 12
#   （两台同时重启、各归各位）里，声明为主库的那台**永远等不到许可**。
#   这和 §2.3 里 IPMI 的 poweredOn 是同一个坑，方向一致。
#
#   而反方向 —— "MAC 不在表里" —— 是**真正的确证**：
#   某台的 MAC 从交换机地址表里消失 = 它已经不在这个网上了，
#   那么它也无法向客户端提供服务，此时提升对端是**正确**的。
#   这就是需求文档 §5 M1.1 说的"纯网络环境下性价比最高的补强"。
#
#   ★ 所以本适配器是**单向判据**：只敢确认"不在"，不敢确认"在"。
#
# ------------------------------------------------------------
# ★★ 最危险的一处：**读不全的表 = 没有的表**
#
#   walk 中途超时、被 ACL 截断、或者交换机的 SNMP 视图只暴露了一部分，
#   都会让"对端的 MAC"读不到。如果此时按"不在表里"处理，结果就是
#   把**我们自己瞎了**变成**确证对端不在服务** —— 一票放行 —— 双主。
#
#   所以：只有 walk **走到自然结束**，才允许回答"不在"。
#   走不完就是 3（看了，但看不出），并在原始输出里写明走到哪一步。
#   见需求文档 R1。
#
# ------------------------------------------------------------
# 配置：/etc/zbx-arbiter/adapters.d/30-snmp-switch.conf（600）
#
#   SNMP_HOST=10.10.0.9
#   SNMP_COMMUNITY='public'
#   SNMP_TIMEOUT=3                   # 可选，单次请求超时（秒）
#   SNMP_RETRIES=1                   # 可选，重试次数
#   SNMP_DEADLINE=8                  # 可选，整轮 walk 的总时限（秒）
#                                    # ★ 要小于 ADAPTER_TIMEOUT（默认 10）
#   SNMP_FDB_MODE=bridge             # bridge | qbridge，默认 bridge
#                                    #   bridge  = BRIDGE-MIB  dot1dTpFdbAddress（单 VLAN）
#                                    #   qbridge = Q-BRIDGE-MIB dot1qTpFdbPort（多 VLAN）
#   SNMP_VLAN=0                      # 可选，qbridge 模式下只看某个 VLAN
#   SNMP_FDB_BASE=1.3.6.1.2.1.17.4.3.1.1   # 可选，覆盖默认的地址表 OID
#   SNMP_PORT_IFINDEX_192.168.2.221=24     # 可选，该节点接在交换机的哪个口
#   SNMP_PORT_IFINDEX_192.168.2.222=23
#
#   ★ 只用 v2c（v1 没有 GetBulk，2000 台规模的转发表会跑不完；
#     v3 要额外的依赖与密钥管理，本适配器不做）。
# ============================================================

import os
import random
import socket
import sys
import time

CONF_DIR = os.environ.get("ARBITER_ADAPTER_CONF_DIR",
                          "/etc/zbx-arbiter/adapters.d")
CONF = os.path.join(CONF_DIR, os.path.basename(__file__).rsplit(".", 1)[0] + ".conf")

DEFAULT_FDB_BASE = "1.3.6.1.2.1.17.4.3.1.1"      # dot1dTpFdbAddress
DEFAULT_QBASE = "1.3.6.1.2.1.17.7.1.2.2.1.2"     # dot1qTpFdbPort
IF_OPER_STATUS = "1.3.6.1.2.1.2.2.1.8"           # ifOperStatus

# ifOperStatus 的取值（RFC 2863）
IF_UP, IF_DOWN, IF_TESTING, IF_UNKNOWN = 1, 2, 3, 4
IF_DORMANT, IF_NOT_PRESENT, IF_LOWER_DOWN = 5, 6, 7
NOT_SERVING = {IF_DOWN, IF_NOT_PRESENT, IF_LOWER_DOWN}

MAX_ROWS = 20000


# ============================================================
# BER / SNMP v2c —— 手写，只用标准库
# ============================================================

def _ber_len(n):
    if n < 0x80:
        return bytes([n])
    out = []
    while n:
        out.insert(0, n & 0xFF)
        n >>= 8
    return bytes([0x80 | len(out)]) + bytes(out)


def _tlv(tag, payload):
    return bytes([tag]) + _ber_len(len(payload)) + payload


def _int(v):
    if v == 0:
        return _tlv(0x02, b"\x00")
    out = []
    n = abs(v)
    while n:
        out.insert(0, n & 0xFF)
        n >>= 8
    if out[0] & 0x80:
        out.insert(0, 0)
    if v < 0:
        out = [(~b) & 0xFF for b in out]     # 本适配器不用负数，留着以防万一
    return _tlv(0x02, bytes(out))


def _octet(b):
    return _tlv(0x04, b)


def _oid(oid_str):
    parts = [int(x) for x in str(oid_str).strip(".").split(".") if x != ""]
    if len(parts) < 2:
        raise ValueError("OID 至少要两段：%r" % oid_str)
    out = [40 * parts[0] + parts[1]]
    for p in parts[2:]:
        if p < 0x80:
            out.append(p)
            continue
        stack = []
        while p:
            stack.insert(0, p & 0x7F)
            p >>= 7
        for i in range(len(stack) - 1):
            stack[i] |= 0x80
        out.extend(stack)
    return _tlv(0x06, bytes(out))


def _read_len(buf, i):
    n = buf[i]
    i += 1
    if n & 0x80:
        cnt = n & 0x7F
        if cnt == 0 or i + cnt > len(buf):
            raise ValueError("BER 长度非法")
        n = int.from_bytes(buf[i:i + cnt], "big")
        i += cnt
    return n, i


def _read_tlv(buf, i):
    if i >= len(buf):
        raise ValueError("BER 截断")
    tag = buf[i]
    i += 1
    ln, i = _read_len(buf, i)
    if i + ln > len(buf):
        raise ValueError("BER 长度越界")
    return tag, buf[i:i + ln], i + ln


def _dec_oid(b):
    if not b:
        return ""
    first = b[0]
    if first < 40:
        parts = [0, first]
    elif first < 80:
        parts = [1, first - 40]
    else:
        parts = [2, first - 80]
    val = 0
    for byte in b[1:]:
        val = (val << 7) | (byte & 0x7F)
        if not (byte & 0x80):
            parts.append(val)
            val = 0
    return ".".join(str(p) for p in parts)


def _within(oid_str, base):
    """oid 是否在 base 这一列之内（等于 base 或 base 的子树）。"""
    return oid_str == base or oid_str.startswith(base + ".")


class SnmpError(Exception):
    pass


class Snmp(object):
    def __init__(self, host, community, timeout=3.0, retries=1):
        self.host = host
        self.community = community.encode("utf-8")
        self.timeout = timeout
        self.retries = retries
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.settimeout(timeout)
        try:
            self.sock.connect((host, 161))
        except OSError as e:
            raise SnmpError("到交换机 %s:161 的 UDP 通道建不起来：%s" % (host, e))

    def close(self):
        try:
            self.sock.close()
        except OSError:
            pass

    def _pdu(self, tag, oid_str, extra_int):
        varbind = _tlv(0x30, _oid(oid_str) + b"\x05\x00")
        body = (_int(self.rid) + _int(extra_int[0]) + _int(extra_int[1])
                + _tlv(0x30, varbind))
        return _tlv(tag, body)

    def _exchange(self, tag, oid_str, extra_int):
        """发一次请求，收一次回答。返回 [(oid, tag, value_bytes), ...]"""
        self.rid = random.randint(1, 0x7FFFFFFF)
        msg = _tlv(0x30, _int(1) + _octet(self.community)
                   + self._pdu(tag, oid_str, extra_int))
        last = None
        for _ in range(self.retries + 1):
            try:
                self.sock.send(msg)
                data = self.sock.recv(65535)
            except socket.timeout:
                last = "超时（%.1fs 无应答）" % self.timeout
                continue
            except OSError as e:
                raise SnmpError("与交换机 %s 通信失败：%s" % (self.host, e))
            try:
                return self._parse(data)
            except SnmpError as e:
                last = str(e)
                continue
        raise SnmpError("交换机 %s 没有给出可用的回答：%s"
                        % (self.host, last or "未知"))

    def _parse(self, data):
        tag, body, _ = _read_tlv(data, 0)
        if tag != 0x30:
            raise SnmpError("报文顶层不是 SEQUENCE")
        i = 0
        t, ver, i = _read_tlv(body, i)
        if t != 0x02 or ver != b"\x01":
            raise SnmpError("不是 SNMP v2c 的应答")
        t, comm, i = _read_tlv(body, i)
        if t != 0x04 or comm != self.community:
            # ★ community 不符 = 这个应答不是给我们的。丢弃，别拿它当数据。
            raise SnmpError("community 不匹配")
        t, pdu, i = _read_tlv(body, i)
        if t not in (0xA2, 0xA8):
            raise SnmpError("PDU 类型 0x%02X 不是应答" % t)
        j = 0
        t, rid, j = _read_tlv(pdu, j)
        got_rid = int.from_bytes(rid, "big") if rid else -1
        if got_rid != self.rid:
            raise SnmpError("request-id 不符（%s != %s）" % (got_rid, self.rid))
        t, es, j = _read_tlv(pdu, j)
        err_status = int.from_bytes(es, "big") if es else 0
        t, ei, j = _read_tlv(pdu, j)
        err_index = int.from_bytes(ei, "big") if ei else 0
        if err_status != 0:
            raise SnmpError("交换机返回 error-status=%d（第 %d 个 varbind）"
                            % (err_status, err_index))
        t, vbl, j = _read_tlv(pdu, j)
        out = []
        k = 0
        while k < len(vbl):
            t, vb, k = _read_tlv(vbl, k)
            m = 0
            t2, ob, m = _read_tlv(vb, m)
            t3, val, m = _read_tlv(vb, m)
            out.append((_dec_oid(ob), t3, val))
        return out

    def walk(self, base, deadline, nrows=MAX_ROWS):
        """GetBulk 走一列。返回 (rows, complete, note)。

        ★★ complete=False 表示**没走完** —— 调用方绝不能把它当成"表已读全"。
        """
        rows = []
        oid = base
        t0 = time.time()
        while len(rows) < nrows:
            if time.time() - t0 > deadline:
                return rows, False, ("总时限 %.0fs 用完，只走到 %s（%d 行）"
                                     % (deadline, oid, len(rows)))
            try:
                got = self._exchange(0xA5, oid, (0, 50))     # GetBulk
            except SnmpError as e:
                if "error-status" in str(e):
                    # 有些老设备不认 GetBulk —— 退化成 GetNext
                    try:
                        got = self._exchange(0xA1, oid, (0, 0))
                    except SnmpError as e2:
                        return rows, False, "walk 中断：%s（退化 GetNext 也失败：%s）" % (e, e2)
                else:
                    return rows, False, "walk 中断：%s" % e
            if not got:
                return rows, False, "交换机返回了空的 varbind 列表"
            progressed = False
            for (o, t, v) in got:
                if t in (0x80, 0x81, 0x82):
                    # endOfMibView / noSuchObject / noSuchInstance —— 自然结束
                    return rows, True, "走到表尾（%d 行）" % len(rows)
                if not _within(o, base):
                    return rows, True, "走出这一列（%d 行）" % len(rows)
                if o == oid and not progressed:
                    # 同一个 OID 又来一遍 = 设备在原地打转，别死循环
                    return rows, False, ("交换机对 %s 反复返回同一个 OID —— "
                                         "无法继续，可能是视图受限" % o)
                rows.append((o, t, v))
                oid = o
                progressed = True
            if not progressed:
                return rows, False, "这一轮没有推进"
        return rows, False, "行数超过上限 %d" % nrows


# ============================================================
# 配置与工具
# ============================================================

def cfg(conf, key, default=""):
    try:
        with open(conf, encoding="utf-8-sig") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                k, sep, v = line.partition("=")
                if not sep or k.strip() != key:
                    continue
                v = v.strip()
                if len(v) >= 2 and v[0] == v[-1] and v[0] in ("'", '"'):
                    v = v[1:-1]
                return v
    except OSError:
        pass
    return default


def norm_mac(s):
    """归一成 aa:bb:cc:dd:ee:ff；认不出来返回 ""。

    ★ 三种写法都要认：冒号、连字符、Cisco 点分（0050.56aa.bbcc）。
      认不出来时返回空串而不是原样返回 —— 空串会让调用方说"查不了"，
      原样返回则会变成一个永远匹配不上的字符串，然后静默地判成"不在表里"。
    """
    s = (s or "").strip().lower()
    for sep in (":", "-"):
        parts = s.split(sep)
        if len(parts) == 6 and all(len(p) == 2 for p in parts):
            try:
                return ":".join("%02x" % int(p, 16) for p in parts)
            except ValueError:
                return ""
    parts = s.split(".")
    if len(parts) == 3 and all(len(p) == 4 for p in parts):
        try:
            return ":".join("%02x" % int(p[i:i + 2], 16)
                            for p in parts for i in (0, 2))
        except ValueError:
            return ""
    if len(s) == 12 and all(c in "0123456789abcdef" for c in s):
        return ":".join(s[i:i + 2] for i in range(0, 12, 2))
    return ""


def say(reason, *raw):
    sys.stdout.write(reason + "\n")
    for line in raw:
        sys.stdout.write("%s\n" % line)


def main():
    if len(sys.argv) < 2 or not sys.argv[1].strip():
        say("没有传入待判定的对端 IP（契约：$1 = 对端 IP）")
        return 2
    peer = sys.argv[1].strip()

    peer_mac = norm_mac(os.environ.get("ARBITER_PEER_MAC"))
    if not os.path.isfile(CONF):
        say("没有 %s —— 这台节点未配置交换机观测" % CONF)
        return 2

    host = cfg(CONF, "SNMP_HOST")
    community = cfg(CONF, "SNMP_COMMUNITY")
    if not host or not community:
        say("%s 里缺 SNMP_HOST 或 SNMP_COMMUNITY —— 配置不完整" % CONF)
        return 2

    mode = (cfg(CONF, "SNMP_FDB_MODE", "bridge") or "bridge").strip().lower()
    if mode not in ("bridge", "qbridge"):
        say("SNMP_FDB_MODE=%s 不认识（只认 bridge / qbridge）" % mode)
        return 2
    base = cfg(CONF, "SNMP_FDB_BASE", "") or (
        DEFAULT_QBASE if mode == "qbridge" else DEFAULT_FDB_BASE)
    vlan = cfg(CONF, "SNMP_VLAN", "").strip()

    if not peer_mac:
        say("本机还没学到对端 %s 的 MAC —— 交换机地址表无从查起" % peer,
            "★ 这条路要求仲裁节点与两台节点在同一二层，且至少成功观测过一次 ARP")
        return 2

    deadline = float(cfg(CONF, "SNMP_DEADLINE", "8") or 8)
    ifindex = cfg(CONF, "SNMP_PORT_IFINDEX_%s" % peer, "").strip()

    snmp = None
    try:
        snmp = Snmp(host,
                    community,
                    timeout=float(cfg(CONF, "SNMP_TIMEOUT", "3") or 3),
                    retries=int(cfg(CONF, "SNMP_RETRIES", "1") or 1))

        # ---- 一、端口状态（配了才查）----
        # 优先级最高：**链路断了就是不在网上**，比地址表更能说明问题。
        # （地址表里可能还留着一条没老化的旧记录。）
        port_state, port_note = None, "未配置 SNMP_PORT_IFINDEX_%s" % peer
        if ifindex:
            try:
                got = snmp._exchange(0xA0, "%s.%s" % (IF_OPER_STATUS, ifindex),
                                     (0, 0))
                if got and got[0][1] == 0x02:
                    port_state = int.from_bytes(got[0][2], "big")
                    port_note = "ifOperStatus.%s = %d" % (ifindex, port_state)
                else:
                    port_note = "ifOperStatus.%s 读到的不是整数" % ifindex
            except SnmpError as e:
                port_note = "ifOperStatus.%s 读不到：%s" % (ifindex, e)

        # ---- 二、地址表 ----
        rows, complete, note = snmp.walk(base, deadline)
        macs = set()
        if mode == "bridge":
            for (o, t, v) in rows:
                if t == 0x04 and len(v) == 6:
                    macs.add(norm_mac(":".join("%02x" % b for b in v)))
        else:
            for (o, t, v) in rows:
                idx = o[len(base) + 1:].split(".")
                if len(idx) < 7:
                    continue
                vv = idx[0]
                if vlan and vv != vlan:
                    continue
                try:
                    macs.add(":".join("%02x" % int(x) for x in idx[-6:]))
                except ValueError:
                    continue
        macs.discard("")

        raw_head = [
            "switch=%s  community=%s  mode=%s  base=%s" % (host, "*" * len(community),
                                                           mode, base),
            "peer=%s  peer_mac=%s" % (peer, peer_mac),
            "fdb: %d 行，%s（complete=%s）" % (len(rows), note, complete),
            "port: %s" % port_note,
        ]

        # ---- 端口断了 = 确证不在网上 ----
        if port_state is not None and port_state in NOT_SERVING:
            names = {IF_DOWN: "down", IF_NOT_PRESENT: "notPresent",
                     IF_LOWER_DOWN: "lowerLayerDown"}
            say("交换机端口确认对端 %s 的链路是 %s —— 它已不在这个网上，无法提供服务"
                % (peer, names.get(port_state, str(port_state))),
                *raw_head)
            return 0

        # ---- ★★ 表没读全，就不许说"不在" ----
        if not complete:
            say("交换机地址表**没有读全**，因此无法确认对端 %s 的 MAC 是否在表里 —— "
                "不完整的表不等于没有的表" % peer,
                *raw_head)
            return 3

        if not macs:
            say("交换机地址表是**空的**（在 %s 下一行都没有）—— 这多半说明看错了表、"
                "或者 community 的视图受限，不能当成'对端不在网上'" % base,
                *raw_head)
            return 3

        if peer_mac in macs:
            say("对端 %s 的 MAC %s 仍在交换机地址表里 —— 它还连在网上，"
                "但这不说明它在服务，本路得不出结论" % (peer, peer_mac),
                *raw_head)
            return 3

        say("对端 %s 的 MAC %s **不在**交换机地址表里（表已读全，共 %d 条）—— "
            "它已不在这个网上，无法提供服务" % (peer, peer_mac, len(macs)),
            *raw_head)
        return 0

    except SnmpError as e:
        say("交换机观测不可用：%s" % e, "switch=%s  peer=%s" % (host, peer))
        return 2
    except Exception as e:  # noqa: BLE001 —— 兜底只能是"不可用"
        say("交换机观测异常：%s: %s" % (type(e).__name__, e),
            "switch=%s  peer=%s" % (host, peer))
        return 2
    finally:
        if snmp is not None:
            snmp.close()


if __name__ == "__main__":
    sys.exit(main())
