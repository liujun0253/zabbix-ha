#!/bin/bash
# ============================================================
# 10-network.sh —— 网络类观测【必选，不可移除】
#
#   类别：★ 否决型（这个文件的存在本身不构成任何许可）
#   强度：B
#   依赖：iputils-arping
#
# 输入：$1 = 待判定的**对端** IP
#       环境：全套配置（VIP / NIC / NODE_A_IP / NODE_B_IP / ARBITER_*）
#             外加 ARBITER_SELF_IP / ARBITER_SELF_MAC / ARBITER_PEER_IP
# 输出：stdout 第一行 = 理由（进 verdict.reason）
#       stdout 其余行 = 原始观测值（进日志，供回溯）
# 退出：0 证据成立（对端确实不在服务）
#       1 证据不成立（对端**在**服务）—— 一票否决
#       2 不可用（我们自己瞎了）
#       3 无结论（看了，但看不出）—— 既不放行也不否决，不计入退化
#
# ------------------------------------------------------------
# ★★ 这个适配器唯一有权说"否决"的只有一件事：**VIP 被别的 MAC 应答了**。
#
#   「对端 ping 不通」「5432 连不上」**不是**许可条件，所以它们只是观测量，
#   不参与退出码。理由见需求文档 §5 M1.2：
#
#     备库活着但没在服务，是**常态**。若把"对端可达"写成否决条件，
#     一台健康的备库（PG 在监听 5432）会让主库**永远等不到启动许可**，
#     §6.1 场景 12（两台同时重启、各归各位）随之失效。
#
#   反过来，"VIP 有人应答"是**真的有人在服务**的网络侧证据：
#   谁绑着 VIP，谁就在接客户端流量。它不是"看不见"，是"看见了别人"。
#
# ★★ 判据①（VIP 归属）的完整规则：
#     无应答                              → 通过（0）
#     应答者 MAC == ARBITER_SELF_MAC      → 通过（0）← 请求方自己绑着，不是别人
#     应答者 MAC ∈ ARBITER_VIP_IGNORE_MAC → 通过（0）← 网络设备/H SRP 之类的已知占用
#     应答者 MAC == 对端或第三方          → **否决（1）**
#     无法判断（没有 arping / 认不出输出） → **不可用（2）**
#
#   ★ 最后一条尤其重要：**判据不可用 ≠ 判据通过**。
#     一个认不出来的 arping 输出，绝不能变成一句"VIP 空闲"。
# ============================================================
set -u

PEER=${1:-}
if [ -z "$PEER" ]; then
    echo "没有传入待判定的对端 IP（契约：\$1 = 对端 IP）"
    exit 2
fi

VIP=${VIP:-}
NIC=${NIC:-}
SELF_IP=${ARBITER_SELF_IP:-}
SELF_MAC=${ARBITER_SELF_MAC:-}
IGNORE=${ARBITER_VIP_IGNORE_MAC:-}

if [ -z "$VIP" ] || [ -z "$NIC" ]; then
    echo "配置里缺 VIP 或 NIC，无法做任何 VIP 判定"
    exit 2
fi

# ------------------------------------------------------------
# 找一个 **iputils** 版的 arping
#
# ★ 这是三处发行版差异之二：`arping` 是两个包，装错的那个永远赢。
#     iputils-arping → /usr/bin/arping    （要这个：支持 -D，输出 "Received N response(s)"）
#     arping         → /usr/sbin/arping   （Habets 版：-D 语义不同，输出 "reply(s)"）
#   systemd 的 PATH 里 /usr/sbin 排在 /usr/bin 前面 —— 所以直接写 `arping`
#   是在赌装了哪个包。这里按绝对路径逐个试，并且**用输出措辞确认**。
# ------------------------------------------------------------
CANDS=("${ARPING_BIN:-}" /usr/bin/arping /bin/arping /usr/sbin/arping /sbin/arping)
ARPING=""

# 第一轮：版本串自报 iputils 的最可信
for cand in "${CANDS[@]}"; do
    [ -n "$cand" ] && [ -x "$cand" ] || continue
    v=$("$cand" -V 2>&1 | tr 'A-Z' 'a-z')
    case "$v" in
        *iputils*) ARPING="$cand"; break ;;
    esac
done

# 第二轮：版本串判不出来（各版本时有时无），退一步真跑一次看措辞
#
# ★ 探测目标用**本机的 NIC 和 VIP**，不要用 127.0.0.1：
#   lo 不是 ARP 介质，iputils 会直接报 "not ARP-capable"，
#   那样两个候选都会"失败"，反而分不出来。
if [ -z "$ARPING" ]; then
    for cand in "${CANDS[@]}"; do
        [ -n "$cand" ] && [ -x "$cand" ] || continue
        probe=$("$cand" -c 1 -w 2 -I "$NIC" "$VIP" 2>&1)
        case "$probe" in
            *"Received"*"response"*) ARPING="$cand"; break ;;
        esac
    done
fi

if [ -z "$ARPING" ]; then
    echo "找不到可用的 iputils-arping —— VIP 归属无法判断（apt install iputils-arping）"
    exit 2
fi

# 取这次 arping 的输出
run_arping() {
    # $1 = 是否加 -D（"dad" / ""）
    local dad="$1"
    if [ "$dad" = "dad" ]; then
        "$ARPING" -D -I "$NIC" -c 3 -w 5 "$VIP" 2>&1
    else
        "$ARPING" -I "$NIC" -c 3 -w 5 "$VIP" 2>&1
    fi
}

# ★ 不看退出码。iputils 的 -D 在若干版本里退出码与文档不符，
#   而这里每一种误读都会把"我们瞎了"变成"VIP 空闲"。只认输出。
LEG1=$(run_arping dad)
N1=$(printf '%s\n' "$LEG1" | sed -n 's/.*Received[[:space:]]\{1,\}\([0-9]\{1,\}\)[[:space:]]\{1,\}response.*/\1/p' | head -1)

if [ -z "$N1" ]; then
    echo "arping 的输出认不出来，无法判断 VIP 是否被占用（判据不可用，不是判据通过）"
    printf '%s\n' "$LEG1" | head -5
    exit 2
fi

# 观测量：对端可达性与两个端口。★ 只打印，不参与退出码。
peer_icmp="不通"
ping -c 2 -W 2 "$PEER" >/dev/null 2>&1 && peer_icmp="通"
peer_5432="不通"
(exec 3<>"/dev/tcp/$PEER/5432") 2>/dev/null && peer_5432="通"
peer_10051="不通"
(exec 3<>"/dev/tcp/$PEER/10051") 2>/dev/null && peer_10051="通"

# ---- 判据①：VIP 归属 ----
if [ "$N1" = "0" ]; then
    echo "VIP $VIP 无人应答（arping -D 收到 0 个应答），对端不在服务"
    echo "arping=$ARPING  vip=$VIP  nic=$NIC  self=$SELF_IP  peer=$PEER"
    echo "观察（不参与判决）：对端 ICMP $peer_icmp，5432 $peer_5432，10051 $peer_10051"
    exit 0
fi

# 有人在应答 —— 取它的 MAC。
# ★ 每次调用单独发子 shell，避免 exec 3<> 的那些句柄串到一起。
LEG2=$(run_arping "")
HOLDER=$(printf '%s\n' "$LEG2" \
    | tr '[]' '  ' \
    | tr 'A-Z' 'a-z' \
    | grep -o '[0-9a-f]\{2\}:[0-9a-f]\{2\}:[0-9a-f]\{2\}:[0-9a-f]\{2\}:[0-9a-f]\{2\}:[0-9a-f]\{2\}' \
    | grep -v '^ff:ff:ff:ff:ff:ff$' \
    | head -1)

if [ -z "$HOLDER" ]; then
    # 有应答但认不出是谁 —— 不能当成"没人持有"
    echo "VIP $VIP 有人在应答，但取不到应答者 MAC —— 认不出是谁在服务，按不通过处理"
    printf '%s\n' "$LEG2" | head -5
    exit 2
fi

SELF_MAC_LC=$(printf '%s' "$SELF_MAC" | tr 'A-Z' 'a-z')

if [ -n "$SELF_MAC_LC" ] && [ "$HOLDER" = "$SELF_MAC_LC" ]; then
    echo "VIP $VIP 由请求方自己（$SELF_IP，MAC $HOLDER）持有 —— 不是别人在服务"
    echo "arping=$ARPING  vip=$VIP  nic=$NIC  peer=$PEER"
    exit 0
fi

# 白名单：网络设备、约定的运维口等等。★ 英文逗号分隔（兼容空格），大小写不敏感。
IGNORE_LC=$(printf '%s' "$IGNORE" | tr 'A-Z' 'a-z' | tr ',' ' ')
for m in $IGNORE_LC; do
    if [ "$HOLDER" = "$m" ]; then
        echo "VIP $VIP 由已知的非节点设备持有（MAC $HOLDER，在忽略名单里）"
        echo "arping=$ARPING  vip=$VIP  nic=$NIC  peer=$PEER"
        exit 0
    fi
done

echo "VIP $VIP 正被 MAC $HOLDER 应答 —— 有别人在服务，不能放行（请求方 $SELF_IP，对端 $PEER）"
echo "arping=$ARPING  vip=$VIP  nic=$NIC  self_mac=${SELF_MAC:-（未知）}"
echo "应答原文："
printf '%s\n' "$LEG2" | head -8
echo "观察（不参与判决）：对端 ICMP $peer_icmp，5432 $peer_5432，10051 $peer_10051"
exit 1
