#!/bin/bash
# ============================================================
# run-adapters.sh —— 仲裁节点的观测周期入口（§5 M1.11）
#
# 由 zbx-arbiter.service（Type=oneshot）触发，zbx-arbiter.timer 每 30 秒拉起一次。
#
# ★ 本文件刻意保持得极薄：它只做一件事 —— 把配置路径交给 arbiter-round.py。
#
#   为什么不把观测逻辑写在这里：适配器的执行与归类要处理超时、非法退出码、
#   stdout 解析、不可用轮次累计。这些在 bash 里全靠在字符串上做判断，
#   而它们的每一种错法都会**静默地**把"我们自己瞎了"变成"对端不在服务" ——
#   那是本方案里最危险的一类错误。所以核心逻辑放在能被 py_compile 检查的
#   Python 里，这里只留一个入口名字（zbx-arbiter.service 的 ExecStart）。
#
# ★★ 只读：不启动、不停止、不重启任何东西，也不下发任何指令。
# ============================================================
set -u

CONF=${ARBITER_CONF:-/etc/zbx-arbiter/arbiter.conf}
ROUND=/opt/zbx-arbiter/arbiter-round.py

if [ ! -r "$CONF" ]; then
    echo "[$(date '+%F %T')] 读不到配置文件 $CONF —— 观测无法进行"
    exit 1
fi

if [ ! -r "$ROUND" ]; then
    echo "[$(date '+%F %T')] 找不到 $ROUND —— 部署不完整"
    exit 1
fi

exec /usr/bin/python3 "$ROUND" --conf "$CONF"
