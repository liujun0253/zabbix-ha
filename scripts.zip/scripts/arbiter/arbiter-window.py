#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ============================================================
# arbiter-window.py —— 维护窗口（§5 M1.8）
#
#   open --minutes 30 --reason '221 内核升级'
#   close
#   show
#
# ★★ 窗口是**全局**的（2026-09-27 改）：没有"对象节点"这个参数 ——
#    窗口一开，**所有**节点来要许可都拿到 deny。旧写法要对一个 IP，
#    而填错它的两种表现（"照样被接管" / "挡住了本该放过的机器"）**都不报错**。
#    ★ --node 参数**故意保留**：带上它会被**拒绝**（退出码 2），不是被忽略 ——
#      见 cmd_open 开头那一段。
#    代价是被维护的那台**自己也**拿不到许可（它计划内重启回来时守卫会拒绝启动，
#    要有人跑 ha-force.py up）—— 换来的是"没有对象、也就没有对象填错"。
#
# ------------------------------------------------------------
# ★★ 为什么是**本机命令**，不是页面上的一个按钮
#
#   需求文档 §5 M1.8 的"入口"一行写的是"仲裁页面上一个按钮"。
#   实现成按钮需要**一个会改状态的 HTTP 接口**，而这个接口：
#
#     · 没有认证（访问控制就是 ARBITER_ALLOW_FROM 那张 IP 白名单）
#     · 与"仲裁节点永久只读"这条不变量正面冲突（页面底下就印着这句话）
#     · 一次误点/一条 curl 就能把**所有**自动接管堵住（窗口是减权限的操作）
#
#   窗口本身是**只能减权限**的，所以它不是提权漏洞；但它能造成一次
#   长达 30 分钟的"明知地放弃自动接管"（§5 M1.8 ⚠️、R13）。
#   这种动作值得一次 sudo 和一次登录 —— 计划内重启本来就要登机器。
#
#   所以：**状态在页面上看得见（含倒计时与下面这条命令），动作在本机执行。**
#   仲裁 HTTP 接口保持"只有 GET"（§5 M1.3），一把锁都不加。
#
# ------------------------------------------------------------
# ★ 窗口 = 减去权限，不是加上权限
#   窗口内，仲裁对**所有**节点一律返回 deny —— 没有例外，包括被维护的那台。
#   所以最坏情况是把一次合法接管推迟到窗口结束，永远不会让谁更容易通过。
#
# ★★ 全局的代价与出口（两件事要一起记）：
#   · 被维护的那台**自己也**拿不到许可 —— 它计划内重启回来时，守卫会拒绝
#     启动 PG（deny 的理由里写着"维护窗口"），要有人在那台上跑
#       sudo /opt/simplified-ha/ha-force.py up
#     （强制令牌解锁的正是仲裁那三条 ⑥⑦⑧，VIP 判据仍然保留）。
#   · 窗口**挡不住人工路径**：ha-force / ha-promote / ha-rejoin 都不查这张许可。
#     所以它挡住的是"自动接管"，不是"人不让它起"。
#
# ★ 有硬上限，自动过期（MAINT_WINDOW_MAX，默认 1800 秒）。
#   开不成"永久"—— 不存在一扇常开的门。
# ============================================================

import argparse
import getpass
import os
import sys
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    import arbiter
except ImportError as e:  # pragma: no cover
    sys.stderr.write(
        "读不到 arbiter.py（%s）—— 维护窗口与仲裁服务必须部署在同一个目录。\n" % e)
    sys.exit(1)


def whoami():
    """谁在开这个窗口。

    ★ 优先 SUDO_USER：本命令要 sudo，而 sudo 会把 USER 改成 root ——
      只记 root 的话，审计日志里"是谁开的窗口"就没了。
    """
    for k in ("SUDO_USER", "LOGNAME", "USER"):
        v = os.environ.get(k)
        if v and v != "root":
            return v
    try:
        return getpass.getuser()
    except Exception:
        return "unknown"


def audit_log(conf, action, detail):
    """append-only 的一行。开窗口是有人值守的动作，必须留痕。"""
    path = os.path.join(conf.state_dir, "maintenance.log")
    line = "[%s] %s by %s: %s\n" % (
        datetime.now().strftime("%F %T"), action, whoami(), detail)
    try:
        os.makedirs(conf.state_dir, exist_ok=True)
        with open(path, "a", encoding="utf-8") as f:
            f.write(line)
    except OSError as e:
        sys.stderr.write("★ 审计日志写不进去（%s）：%s\n" % (path, e))
    return line.rstrip()


def fmt_sec(s):
    s = int(s)
    if s >= 60:
        return "%d 分 %d 秒" % (s // 60, s % 60)
    return "%d 秒" % s


def cmd_show(conf, store, args):
    m = store.maintenance()          # ★ 已过滤掉过期的
    if not m:
        print("维护窗口：未开启。")
        raw_path = os.path.join(conf.state_dir, "maintenance.json")
        if os.path.exists(raw_path):
            print("（%s 里有一条已过期的记录，它不起作用 —— "
                  "窗口是自动过期的，不需要手工清理）" % raw_path)
        return 0
    print("维护窗口：★ 开启中（全局）")
    print("  范围       : ★★ **所有**节点 —— 窗口期内每一台来要许可的节点都拿到 deny")
    print("  剩余       : %s（%s 到期）"
          % (fmt_sec(m.get("remaining_sec", 0)),
             datetime.fromtimestamp(m.get("end_epoch", 0))
             .strftime("%F %T")))
    print("  开启时刻   : %s"
          % datetime.fromtimestamp(m.get("start_epoch", 0)).strftime("%F %T"))
    print("  开启人     : %s" % (m.get("by") or "?"))
    print("  事由       : %s" % (m.get("reason") or "（未写）"))
    if m.get("node"):
        # ★ 升级前留下的旧格式文件：判定侧已经不看 node 了（judge_node 前置 2
        #   只问"有没有窗口"），所以它的实际行为与全局窗口**完全一致** ——
        #   这里必须说出来，否则人会以为"对象那台照常判定"。
        print("  ★ 这条记录是升级前的旧格式（里面还写着对象 %s）—— "
              "判定侧已经不看它了，" % m.get("node"))
        print("    现在的行为与全局窗口完全一致：**两台都拿不到许可**。")
    print()
    print("窗口内：**所有**节点一律 deny，没有例外（包括计划重启的那台）；")
    print("        要它在窗口内起来，只能在本机跑 ha-force.py")
    print("        （强制令牌仍然查 VIP，只解锁仲裁那三条）。")
    print("关闭：  sudo %s close" % os.path.abspath(__file__))
    return 0


def cmd_open(conf, store, args):
    if args.node is not None:
        # ★★ 响亮地失败：老命令必须**开不出窗口**，而不是开出一个他没想到的
        #    全局窗口。直接删掉 --node 只会得到一句 argparse 的
        #    "unrecognized arguments" —— 人分不清是语义变了还是自己手滑，
        #    下一件事就是把 --node 去掉重跑，于是**悄没声地**开出一个全局窗口。
        sys.stderr.write(
            "★ --node 已经取消：维护窗口现在只有一种 —— **全局窗口**。\n"
            "  窗口一开，**所有**节点来要许可都拿到 deny；没有\"对象节点\"这个\n"
            "  参数了，也就不存在对象填错（旧写法里填错的两种表现都不报错）。\n"
            "  你刚写的是旧命令，它**没有**被执行，也没有写出任何文件。\n"
            "  确认你确实要让**两台**都拿不到自动接管许可之后，去掉 --node 重跑：\n"
            "    sudo %s open --minutes 30 --reason '221 内核升级'\n"
            % os.path.abspath(__file__))
        return 2

    want_sec = int(args.minutes * 60)
    if want_sec <= 0:
        # ★ --minutes 0.01 会算出 0 秒：报"已开启"，其实立刻过期。
        sys.stderr.write(
            "★ --minutes 太小（%g 分钟 = %d 秒）：窗口会「开了就过期」。\n"
            "  最小 1 秒；要取消窗口请用 close。\n" % (args.minutes, want_sec))
        return 2

    max_sec = conf.getint("MAINT_WINDOW_MAX", 1800)
    sec = min(want_sec, max_sec)
    clamped = sec < want_sec

    by = whoami()
    old = store.maintenance()
    m = store.set_maintenance(args.minutes, args.reason, by)

    line = audit_log(conf, "MAINTENANCE_OPEN",
                     "scope=global want=%ds granted=%ds replaced=%ds reason=%s"
                     % (want_sec, sec,
                        (old.get("remaining_sec", 0) if old else 0),
                        args.reason or "-"))
    print("维护窗口已开启（★★ 全局）。")
    print("  影响范围 : **所有**节点 —— 窗口期内每一台来要许可的节点都拿到 deny")
    print("  时长     : %s（到 %s）"
          % (fmt_sec(m["end_epoch"] - m["start_epoch"]),
             datetime.fromtimestamp(m["end_epoch"]).strftime("%F %T")))
    if clamped:
        # ★ 必须说出来。悄悄截断会让人以为还有两个小时，而实际上已经快到期了。
        print("  ★★ 你要的是 %s，但 MAINT_WINDOW_MAX=%d 秒是硬上限，"
              "已截断成 %s。" % (fmt_sec(want_sec), max_sec, fmt_sec(sec)))
    print("  开启人   : %s" % by)
    if old:
        print("  ★ 已替换原有窗口：原本还剩 %s" % fmt_sec(old.get("remaining_sec", 0)))
    print()
    print("  ⚠️ 这段时间**明知地放弃自动接管**：**两台**都不会被自动接管。")
    print("     计划内重启的那台回来时守卫会拒绝启动 —— 要它起来就在**那台**上跑")
    print("     ha-force.py up（强制令牌仍然查 VIP，只解锁仲裁那三条）。")
    print("     真出故障时同样：在**要接管的那台**上跑 ha-force.py，"
          "并在操作记录里写明原因。")
    print()
    if not (args.reason or "").strip():
        print("  ★ 事由是空的：窗口没有\"对象\"字段了，以后没人说得清这个窗口")
        print("    当初是给谁开的。建议 close 掉重开，并在 --reason 里写明是哪一台。")
    else:
        print("  ★ 哪一台要动手，只有 --reason 这句话记得下来（窗口没有\"对象\"字段）。")
    print("  倒计时与剩余秒数：仲裁页面 / /state 的 maintenance.remaining_sec；")
    print("  ★ maintenance_remaining_sec 必须已进 Zabbix 告警 —— "
          "否则开完窗口就去开会了。")
    print("  提前结束：sudo %s close" % os.path.abspath(__file__))
    print("  —— %s" % line)
    return 0


def cmd_close(conf, store, args):
    m = store.maintenance()
    store.clear_maintenance()
    if m:
        # ★ 审计写 scope=global 是**实话**：判定侧不看 node（judge_node 前置 2
        #   只问"有没有窗口"），所以旧格式窗口关掉时，恢复的就是全局的许可。
        line = audit_log(conf, "MAINTENANCE_CLOSE",
                         "scope=global had=%ds remaining"
                         % m.get("remaining_sec", 0))
        print("维护窗口已关闭。关闭时还剩 %s。"
              % fmt_sec(m.get("remaining_sec", 0)))
        print("—— %s" % line)
    else:
        print("没有生效中的维护窗口（可能已自动过期）。")
    print("★ **两台**的接管资格**即刻**恢复 —— 如果谁正等在这个窗口上，"
          "下一个轮询周期（30 秒内）就会拿到许可。")
    return 0


def minutes_arg(s):
    """--minutes 的取值校验。

    ★ 走 argparse 的 type=：出错时 argparse 自己打印用法并以 2 退出 ——
      与本文件的退出码约定一致（0 成功 / 1 读不到配置 / 2 校验失败）。
    ★ 挡掉 nan 与 ±inf：它们能被 float() 接受，但到 int() 那一步会抛
      裸 traceback（"窗口开没开成"反倒看不清）。
    """
    try:
        v = float(s)
    except ValueError:
        raise argparse.ArgumentTypeError("不是数字：%s" % s)
    if v != v or v in (float("inf"), float("-inf")):
        raise argparse.ArgumentTypeError("必须是有限数字（nan / inf 不是时长）：%s" % s)
    return v


def main():
    ap = argparse.ArgumentParser(
        prog="arbiter-window.py",
        description="仲裁节点维护窗口（§5 M1.8）。★ 全局：窗口期内所有节点一律 deny。"
                    "只能减权限，硬上限，自动过期。")
    sub = ap.add_subparsers(dest="cmd")

    p_open = sub.add_parser("open", help="开启维护窗口（★ 全局，窗口期内所有节点一律 deny）")
    # ★★ 这个参数是**故意保留**的，不许删！现场手册与旧笔记里写的还是
    #    `--node 192.168.2.221`。删掉它只会得到一句 argparse 的
    #    "unrecognized arguments"，人只会把 --node 去掉重跑 ——
    #    那样就是**悄悄**开出一个全局窗口。留着它，才能当面拒绝并解释。
    p_open.add_argument("--node", default=None,
                        help="★ 已取消：窗口现在是全局的。带上本参数会被**拒绝**，"
                             "不是被忽略。")
    p_open.add_argument("--minutes", type=minutes_arg, required=True,
                        help="时长（分钟），受 MAINT_WINDOW_MAX 硬上限约束")
    p_open.add_argument("--reason", default="",
                        help="事由，写进审计与页面。★ 哪一台要动手只能写在这里"
                             "（例：'221 内核升级'）")
    p_open.set_defaults(func=cmd_open)

    p_close = sub.add_parser("close", help="立即关闭维护窗口")
    p_close.set_defaults(func=cmd_close)

    p_show = sub.add_parser("show", help="查看当前窗口")
    p_show.set_defaults(func=cmd_show)

    args = ap.parse_args()
    if not args.cmd:
        ap.print_help()
        return 2

    conf_path = os.environ.get("ARBITER_CONF", arbiter.CONF_FILE)
    if not os.path.exists(conf_path):
        sys.stderr.write("★ 读不到 %s —— 维护窗口需要它来确定状态目录与硬上限。\n"
                         % conf_path)
        return 1
    conf = arbiter.Conf(conf_path)
    store = arbiter.Store(conf)
    return args.func(conf, store, args)


if __name__ == "__main__":
    sys.exit(main())
